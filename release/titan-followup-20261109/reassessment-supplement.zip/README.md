# Additional CETUS numerical checks

This package contains the thirty epoch-100 CNN evaluations, analyses of the original validation choices, and thirty-seven SAR and map excerpts. It uses the unchanged `initialization-supplement.zip`, whose SHA256 is `ada744e9278f4fbac5f5f953b5688132ad0b080b35cff32ed23b7f02c3192486`. That companion supplies the anonymous catalog, five geographic divisions, original test predictions and compact validation histories.

From the extracted directory, run with Python and NumPy:

```sh
python -B check.py --initialization-zip ../initialization-supplement.zip
```

The checker verifies file hashes, reconstructs metrics and comparisons from the saved arrays, and prints its results. It reads the earlier ZIP directly without importing its Python code. It requires no model library, weights, image download or network access.

Class IDs are 0 for Plains, 1 for Dunes, 2 for Hummocky, 3 for Labyrinths, 4 for Lakes and 5 for Craters. The epoch-100 records preserve validation and test image order, labels, integer predictions, and the original float32 logits and probabilities. Predictions must equal the class with the largest logit. Any disagreement with the class having the largest probability is counted separately. Original test predictions come from the earlier package and were checked for exact equality with the corresponding execution records during assembly. Original validation metrics can be reconstructed from the confusion histories; their logits are omitted.

Selection checks retain every original epoch and learning rate. Counts and score differences after removing one validation image are calculated from the supplied records of those removals. Per-epoch prediction vectors are omitted, so these checks cannot independently regenerate all removal scores. The TSV identifies the class with the largest absolute contribution and retains the sign of that contribution.

The thirty-seven NPZ excerpts are unchanged from the inspected inputs. The checker reconstructs masks from positive SAR DN values, the weights from each corresponding group of four SAR pixels, and map votes under the original, weighted, all-four-valid and any-valid rules. It checks denominators, ties, margins and the vote-loss identity. These excerpts cover the cases discussed in the paper. They do not supply the full image collection, repeat the whole-catalog analysis, or establish geological accuracy or map registration. Separate analyses of edge bands and connected missing areas are outside these checks.

For the epoch comparison, the three training seeds are paired in each region. Regional means receive equal weight, and sample standard deviations use `ddof=1`. Absolute tolerances are 1e-15 for saved metrics, 1e-6 for probability and softmax consistency, and 1e-12 for the saved loss ratio. The checker does not regenerate GPU probabilities or the loss terms. Equality with the earlier epoch-100 validation file was checked during assembly; recipient checks use the supplied validation record, its digest and the corresponding confusion history.

The original `LICENSE`, `DATA_LICENSES.md`, `THIRD_PARTY_NOTICES.md` and `licenses/CROMA-LICENSE` accompany these numerical records and processed Cassini SAR/map excerpts. Retain their citations, credits and notices when using or redistributing the material. This package supplies no broader image-hosting or licensing claim.

These checks reconstruct arithmetic from saved records. They do not repeat inference or training, establish convergence or a causal effect of initialization, or supply model checkpoints. Verification of the original execution is recorded separately from this numerical reconstruction.
