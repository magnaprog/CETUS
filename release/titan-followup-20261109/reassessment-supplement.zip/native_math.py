"""Saved-record arithmetic only; extracted from the reviewed CPU checker. No model code."""
import hashlib, json, math
import numpy as np
NAMES = ['plains','dunes','hummocky','labyrinths','lakes','craters']
GRID = {(f,a,s) for f in range(5) for a in ('scratch','pretrained') for s in range(3)}
METRICS = ['macro_f1','balanced_accuracy','kappa','precision_per_class','recall_per_class','f1_per_class']
ATOL = 1e-15


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode())


def pairs(items):
    value = {}
    for key, item in items:
        need(key not in value, 'Duplicate JSON key: ' + key)
        value[key] = item
    return value


def number(value):
    out = float(value)
    need(math.isfinite(out), 'Nonfinite JSON number')
    return out


def encode(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def identity(cell):
    need(isinstance(cell, list) and len(cell) == 3 and type(cell[0]) is int
         and type(cell[2]) is int and isinstance(cell[1], str), 'Malformed cell identity')
    return tuple(cell)


def complete_grid(rows):
    keys = [identity(row['cell']) for row in rows]
    need(len(keys) == 30 and len(set(keys)) == 30 and set(keys) == GRID, 'Exact30 grid required')
    return {identity(row['cell']): row for row in rows}


def numeric(actual, expected, message, atol=ATOL):
    a, b = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
    need(a.shape == b.shape and np.isfinite(a).all() and np.allclose(a, b, atol=atol, rtol=0), message)
    return float(np.max(np.abs(a - b)))


def integers(actual, expected, message):
    values = np.asarray(actual)
    need(values.dtype.kind in 'iu' and np.array_equal(values, expected), message)


def native_metrics(saved, ordered):
    """Recompute from native predictions; never substitute probability argmax."""
    ids = saved['tile_ids']; labels = np.asarray(saved['labels']); pred = np.asarray(saved['predictions'])
    need(isinstance(ids, list) and all(isinstance(x, str) for x in ids)
         and len(ids) == len(set(ids)) and len(ids) > 0, 'Duplicate/empty/invalid tile IDs')
    need(ids == ordered['tile_ids'] and saved['labels'] == ordered['labels'], 'Original ordered population differs')
    need(saved['class_order'] == list(range(6)) and all(type(c) is int for c in saved['class_order']), 'Class order differs')
    n = len(ids)
    need(labels.shape == pred.shape == (n,) and labels.dtype.kind in 'iu' and pred.dtype.kind in 'iu'
         and ((labels >= 0) & (labels < 6)).all() and ((pred >= 0) & (pred < 6)).all(), 'Labels/predictions invalid')
    support = np.bincount(labels, minlength=6)
    missing = [NAMES[k] for k in np.flatnonzero(support == 0)]
    need(not missing, 'Six-class result unavailable; missing truth classes: ' + repr(missing))
    need(saved['logits_dtype'] == saved['probabilities_dtype'] == 'float32', 'Native dtype differs')
    logits = np.asarray(saved['logits'], dtype=np.float64)
    prob = np.asarray(saved['probabilities'], dtype=np.float64)
    need(logits.shape == prob.shape == (n, 6) and np.isfinite(logits).all() and np.isfinite(prob).all(), 'Native array shape/finiteness')
    need(np.array_equal(logits, logits.astype(np.float32).astype(np.float64))
         and np.array_equal(prob, prob.astype(np.float32).astype(np.float64)), 'Values do not match native float32 dtype')
    need(((prob >= 0) & (prob <= 1)).all(), 'Probability range')
    rows_error = numeric(prob.sum(1), np.ones(n), 'Probability row sums', 1e-6)
    need(np.array_equal(logits.argmax(1), pred), 'Native predictions differ from logits argmax')
    p_argmax = prob.argmax(1)
    different = np.flatnonzero(pred != p_argmax)
    need(type(saved['probability_argmax_disagreements']) is int
         and saved['probability_argmax_disagreements'] == len(different), 'Probability argmax disagreement count')
    shifted = logits - logits.max(1, keepdims=True)
    exp = np.exp(shifted); softmax = exp / exp.sum(1, keepdims=True)
    softmax_error = numeric(prob, softmax, 'Native probabilities/logits consistency', 1e-6)
    cm = np.bincount(labels * 6 + pred, minlength=36).reshape(6, 6)
    tp = cm.diagonal(); predicted = cm.sum(0)
    precision = np.divide(tp, predicted, out=np.zeros(6), where=predicted > 0)
    recall = tp / support
    f1 = 2 * tp / (support + predicted)
    expected = int(np.dot(support, predicted))
    denominator = n * n - expected
    need(denominator > 0, 'Kappa denominator unavailable')
    metrics = {'macro_f1': float(f1.mean()), 'balanced_accuracy': float(recall.mean()),
               'kappa': float((n * int(tp.sum()) - expected) / denominator),
               'precision_per_class': precision.tolist(), 'recall_per_class': recall.tolist(), 'f1_per_class': f1.tolist()}
    errors = {name: numeric(saved[name], value, 'Metric mismatch: ' + name) for name, value in metrics.items()}
    for name, value in {'confusion_matrix': cm, 'support_per_class': support,
                        'true_positive': tp, 'false_positive': predicted - tp, 'false_negative': support - tp}.items():
        integers(saved[name], value, 'Integer count mismatch: ' + name)
    loss, numerator, den = (saved[k] for k in ('loss', 'loss_numerator', 'loss_denominator'))
    need(all(type(x) in (int, float) and math.isfinite(x) for x in (loss, numerator, den))
         and loss >= 0 and numerator >= 0 and den > 0, 'Invalid loss ratio inputs')
    numeric(loss, numerator / den, 'Weighted loss ratio', 1e-12)
    return {**metrics, 'rows': n, 'class_order': NAMES, 'confusion_matrix': cm.tolist(),
        'support_per_class': support.tolist(), 'predicted_counts': predicted.tolist(),
        'true_positive': tp.tolist(), 'false_positive': (predicted - tp).tolist(), 'false_negative': (support - tp).tolist(),
        'missing_truth_classes': missing, 'missing_predicted_classes': [NAMES[k] for k in np.flatnonzero(predicted == 0)],
        'weighted_loss': {'saved_loss': loss, 'numerator': numerator, 'denominator': den, 'generation_replayed': False},
        'native_probability_argmax_disagreements': len(different),
        'probability_argmax_disagreement_rows': [{'index': int(i), 'tile_id': ids[i], 'native_prediction': int(pred[i]),
            'probability_argmax': int(p_argmax[i])} for i in different],
        'max_probability_row_sum_error': rows_error, 'max_float64_softmax_consistency_error': softmax_error,
        'max_saved_metric_error': max(errors.values()),
        'vector_digests': {key: digest(saved[key]) for key in ('tile_ids', 'labels', 'predictions', 'logits', 'probabilities')},
        'metric_prediction_rule': 'saved native predictions, verified equal to native logits argmax'}


def stats(values):
    a = np.asarray(values, dtype=float)
    need(len(a) in (3, 5) and np.isfinite(a).all(), 'Aggregation requires3 seeds or5 regional means')
    return {'n': len(a), 'mean': a.mean(axis=0).tolist(), 'sample_sd': a.std(axis=0, ddof=1).tolist()}


def metric_difference(a, b):
    return {key: (np.asarray(a[key]) - np.asarray(b[key])).tolist() for key in METRICS}


def metric_summary(values):
    return {key: stats([v[key] for v in values]) for key in METRICS}


def aggregate(records, role):
    by = {tuple(r['cell']): r for r in records}
    need(set(by) == GRID and len(records) == 30, 'Aggregation grid differs')
    regions, contrasts, changes, double = [], [], [], []
    for fold in range(5):
        for arm in ('scratch', 'pretrained'):
            rows = [by[fold, arm, seed]['roles'][role] for seed in range(3)]
            policies = {policy: metric_summary([r[policy] for r in rows]) for policy in ('selected', 'epoch100')}
            differences = [metric_difference(r['epoch100'], r['selected']) for r in rows]
            regions.append({'fold': fold, 'region': fold + 1, 'initialization': arm, 'seed_ids': [0, 1, 2],
                            'policies': policies, 'support_per_class': rows[0]['selected']['support_per_class']})
            changes.append({'fold': fold, 'region': fold + 1, 'initialization': arm, 'seed_ids': [0, 1, 2],
                            'seed_differences': differences, 'metrics': metric_summary(differences)})
        paired = {}
        for policy in ('selected', 'epoch100'):
            paired[policy] = [metric_difference(by[fold, 'pretrained', seed]['roles'][role][policy],
                                                by[fold, 'scratch', seed]['roles'][role][policy]) for seed in range(3)]
            contrasts.append({'fold': fold, 'region': fold + 1, 'policy': policy, 'seed_ids': [0, 1, 2],
                              'seed_differences': paired[policy], 'metrics': metric_summary(paired[policy])})
        difference = [metric_difference(paired['epoch100'][s], paired['selected'][s]) for s in range(3)]
        double.append({'fold': fold, 'region': fold + 1, 'seed_ids': [0, 1, 2], 'seed_differences': difference,
                       'metrics': metric_summary(difference)})
    equal = {'policies': {}, 'epoch100_minus_selected': {}, 'pretrained_minus_scratch': {}}
    for arm in ('scratch', 'pretrained'):
        rows = [r for r in regions if r['initialization'] == arm]
        equal['policies'][arm] = {policy: {key: stats([r['policies'][policy][key]['mean'] for r in rows])
                                                 for key in METRICS} for policy in ('selected', 'epoch100')}
        equal['epoch100_minus_selected'][arm] = {key: stats([r['metrics'][key]['mean'] for r in changes if r['initialization'] == arm]) for key in METRICS}
    for policy in ('selected', 'epoch100'):
        equal['pretrained_minus_scratch'][policy] = {key: stats([r['metrics'][key]['mean'] for r in contrasts if r['policy'] == policy]) for key in METRICS}
    equal['change_in_initialization_contrast'] = {key: stats([r['metrics'][key]['mean'] for r in double]) for key in METRICS}
    return {'role': role, 'region_initialization': regions, 'epoch100_minus_selected': changes,
            'pretrained_minus_scratch': contrasts, 'change_in_initialization_contrast': double,
            'equal_region': equal, 'sd_definition': 'sample SD ddof1;3 paired seeds within region,5 regional means across regions; descriptive, not a CI'}
