"""Reconstruct saved numerical records from the complete companion and old ZIP."""
import argparse
import gzip
from pathlib import Path, PurePosixPath

import companion as c
from table_math import table_check


def checked_member(root,manifest,name):
    rel=PurePosixPath(name)
    c.need(not rel.is_absolute() and '..' not in rel.parts and str(rel)==name,'Unsafe member name')
    path=root/name
    c.need(path.is_file() and path.resolve()==path and not path.is_symlink(),'Missing or linked member')
    raw=path.read_bytes()
    c.need(c.nm.sha(raw)==manifest['files'][name]['sha256'] and len(raw)==manifest['files'][name]['bytes'],'Member binding differs')
    return raw


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--initialization-zip',type=Path,required=True)
    args=parser.parse_args();root=args.root.resolve()
    manifest=c.loads((root/'MANIFEST.json').read_bytes())
    c.need(manifest['schema']=='cetus-reassessment-numeric-v1' and manifest['status']=='complete30_parent_admitted','Complete admitted payload required')
    c.need(manifest['dependency_sha256']==c.DEPENDENCY_SHA,'Dependency binding differs')
    for name in manifest['files']:checked_member(root,manifest,name)
    dep=c.dependency(args.initialization_zip)
    def read(name):
        raw=checked_member(root,manifest,name)
        if name.endswith('.gz'):raw=gzip.decompress(raw)
        c.public_text(raw);return c.loads(raw)
    selection=read('data/selection.json.gz');labels=read('data/labels.json');epoch=read('data/epoch100.json.gz')
    # Refuse partial grids before claiming any policy summary.
    c.nm.complete_grid(epoch['cells'])
    numerical=c.check_selection(selection,dep,checked_member(root,manifest,'data/history-summary-explicit.tsv'))
    for row in labels['cases']:
        c.need(row['source_packet']['path']=='cases/'+row['tile_id']+'.npz','Packet reference')
        c.check_packet(checked_member(root,manifest,row['source_packet']['path']),row,dep['tiles'][row['tile_id']])
    label_result=c.label_summary(labels)
    summaries=c.check_full_grid(epoch['cells'],dep,epoch['targets'])
    table=table_check(summaries,read('data/table-proof.json'),checked_member(root,manifest,'tables/epoch100.tex'))
    print(c.encode({'status':'supplied_numerical_records_reconstructed','selection':numerical,'labels':label_result,
        'policy_metrics':summaries,'paper_table':table,'model_inference_performed':False}).decode(),end='')


if __name__=='__main__':main()
