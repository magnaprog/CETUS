"""Saved-record arithmetic only; extracted from the reviewed CPU checker. No model code."""
import numpy as np
from native_math import need as require
CLASSES = ['plains','dunes','hummocky','labyrinths','lakes','craters']
LRS = [0.0001,0.001,0.01]
TOL = 1e-15


def f1(matrix):
    support = matrix.sum(axis=-1)
    predicted = matrix.sum(axis=-2)
    den = support + predicted
    return np.divide(2 * np.diagonal(matrix, axis1=-2, axis2=-1), den,
                     out=np.zeros_like(den, dtype=float), where=den > 0)


def close(a, b, label, atol=TOL):
    require(np.allclose(a, b, rtol=0, atol=atol), label)
    return float(np.max(np.abs(np.asarray(a) - np.asarray(b))))


def distribution(values):
    a = np.asarray(values, dtype=float)
    return {'n': len(a), 'min': float(a.min()), 'median': float(np.median(a)),
            'mean': float(a.mean()), 'max': float(a.max())} if len(a) else {'n': 0}


def persistence(scores, chosen, eligible, deficit_pp):
    mask = eligible & ((scores[chosen] - scores) * 100 <= deficit_pp)
    epochs = np.flatnonzero(mask) + 1
    runs = []
    for epoch in epochs.tolist():
        if runs and epoch == runs[-1][-1] + 1:
            runs[-1].append(epoch)
        else:
            runs.append([epoch])
    containing = next((r for r in runs if chosen + 1 in r), [])
    return {'deficit_pp': deficit_pp, 'epochs': epochs, 'count': len(epochs),
            'first_epoch': int(epochs[0]), 'last_epoch': int(epochs[-1]),
            'longest_contiguous_run': max(map(len, runs)), 'number_of_runs': len(runs),
            'selected_contiguous_run': containing, 'selected_run_length': len(containing)}


def contrast(class_f1, chosen, other, scores):
    if other is None:
        return None
    contributions = (class_f1[chosen] - class_f1[other]) * 100 / 6
    gap = float((scores[chosen] - scores[other]) * 100)
    close(contributions.sum(), gap, 'Class contribution sum', 1e-12)
    return {'reference_epoch': other + 1, 'score_difference_pp': gap,
            'class_contributions_pp': contributions,
            'reference_f1_per_class': class_f1[other]}


def rate_analysis(records):
    output = []
    for fold in range(5):
        for arm in ['pretrained', 'scratch']:
            candidates = sorted([r for r in records if r['phase'] == 'tuning' and r['fold'] == fold and r['initialization'] == arm], key=lambda r:r['initial_lr'])
            require([r['initial_lr'] for r in candidates] == LRS, 'Rate grid incomplete')
            scores = np.array([r['accepted_score'] for r in candidates])
            chosen = int(np.argmax(scores))
            ranking = sorted(range(3), key=lambda i: (-scores[i], LRS[i]))
            other = ranking[1]
            finals = [r for r in records if r['phase'] == 'final' and r['fold'] == fold and r['initialization'] == arm]
            require(len(finals) == 3 and all(r['initial_lr'] == LRS[chosen] for r in finals), 'Accepted rate changed')
            best = np.array([r['single_image_deletion']['best_scores'] for r in candidates])
            winners = np.argmax(best, axis=0)
            margin = (scores[chosen] - scores[other]) * 100
            cf = np.array([r['selected_f1_per_class'] for r in candidates])
            contributions = (cf[chosen] - cf[other]) * 100 / 6
            close(contributions.sum(), margin, 'Rate class contribution sum', 1e-12)
            omissions = []
            for k, name in enumerate(CLASSES):
                values = [r['class_term_omission'][k]['five_term_score'] for r in candidates]
                winner = int(np.argmax(values))
                omissions.append({'omitted_class': name, 'diagnostic_lr': LRS[winner],
                    'changed': winner != chosen,
                    'candidate_best_scores': values,
                    'candidate_epochs': [r['class_term_omission'][k]['diagnostic_epoch'] for r in candidates]})
            output.append({'fold': fold, 'region': fold + 1, 'initialization': arm,
                'accepted_lr': LRS[chosen], 'runner_up_lr': LRS[other], 'margin_pp': margin,
                'class_contributions_to_margin_pp': contributions,
                'candidates': [{'lr': r['initial_lr'], 'selected_epoch': r['accepted_selected_epoch'],
                    'selected_score': r['accepted_score'], 'deficit_pp': (scores[chosen]-r['accepted_score'])*100,
                    'class_contributions_to_deficit_pp': (cf[chosen]-cf[i])*100/6,
                    'result': r['result']} for i,r in enumerate(candidates)],
                'class_term_omission': omissions,
                'single_image_deletion': {'valid_count': best.shape[1],
                    'undefined_count': candidates[0]['single_image_deletion']['undefined_count'],
                    'switch_count': int(np.sum(winners != chosen)),
                    'winning_lr_counts': {str(LRS[i]): int(np.sum(winners == i)) for i in range(3)},
                    'winner_lrs': np.array(LRS)[winners],
                    'winning_candidate_epochs': [int(candidates[w]['single_image_deletion']['winner_epochs'][j]) for j,w in enumerate(winners)],
                    'accepted_rate_regret_pp': distribution((best.max(axis=0) - best[chosen]) * 100)}})
    return output


def summarize(records, rates):
    groups = []
    for phase in ['tuning', 'final']:
        for arm in ['pretrained', 'scratch']:
            rows = [r for r in records if r['phase'] == phase and r['initialization'] == arm]
            groups.append({'phase': phase, 'initialization': arm, 'histories': len(rows),
                'selected_epochs': distribution([r['accepted_selected_epoch'] for r in rows]),
                'epoch_margin_pp': distribution([r['epoch_margin_pp'] for r in rows]),
                'epoch_margins_at_most_0_1pp': sum(r['epoch_margin_pp'] <= .1 for r in rows),
                'exact_tied_maxima_histories': sum(len(r['tied_maximum_epochs']) > 1 for r in rows),
                'near_peak_0_5pp_count': distribution([r['persistence'][2]['count'] for r in rows]),
                'near_peak_0_5pp_selected_run': distribution([r['persistence'][2]['selected_run_length'] for r in rows]),
                'selected_minus100_pp': distribution([r['selected_minus_epoch100_pp'] for r in rows]),
                'histories_with_any_single_deletion_switch': sum(r['single_image_deletion']['switch_count'] > 0 for r in rows),
                'single_deletion_switch_count_sum': sum(r['single_image_deletion']['switch_count'] for r in rows),
                'single_deletion_valid_count_sum': sum(r['single_image_deletion']['valid_count'] for r in rows),
                'single_deletion_undefined_count_sum': sum(r['single_image_deletion']['undefined_count'] for r in rows),
                'class_term_omission_epoch_changes': {c: sum(r['class_term_omission'][k]['changed'] for r in rows) for k,c in enumerate(CLASSES)}})
    val_regions = []
    for fold in range(5):
        entry = {'fold': fold, 'region': fold + 1}
        for arm in ['pretrained', 'scratch']:
            rows = [r for r in records if r['phase'] == 'final' and r['fold'] == fold and r['initialization'] == arm]
            entry[arm] = {'accepted_mean': float(np.mean([r['accepted_score'] for r in rows])),
                'epoch100_mean': float(np.mean([r['epoch100_score'] for r in rows]))}
        entry['accepted_pretrained_minus_scratch_pp'] = (entry['pretrained']['accepted_mean']-entry['scratch']['accepted_mean'])*100
        entry['epoch100_pretrained_minus_scratch_pp'] = (entry['pretrained']['epoch100_mean']-entry['scratch']['epoch100_mean'])*100
        val_regions.append(entry)
    return {'history_groups': groups,
        'rate_margins_pp': distribution([r['margin_pp'] for r in rates]),
        'rate_choices_changed_by_any_single_deletion': sum(r['single_image_deletion']['switch_count'] > 0 for r in rates),
        'class_term_omission_rate_changes': {c: sum(r['class_term_omission'][k]['changed'] for r in rates) for k,c in enumerate(CLASSES)},
        'validation_only_regions': val_regions,
        'validation_only_equal_region': {name: float(np.mean([r[name] for r in val_regions])) for name in ['accepted_pretrained_minus_scratch_pp','epoch100_pretrained_minus_scratch_pp']},
        'rare_case_region1_pretrained_seed1': next({k:v for k,v in r.items() if k in ['cell','accepted_selected_epoch','validation_support','epoch_margin_pp','persistence','contrasts','selected_f1_per_class','selected_minus_epoch100_pp']} for r in records if r['cell'] == ['final',0,'pretrained',1])}
