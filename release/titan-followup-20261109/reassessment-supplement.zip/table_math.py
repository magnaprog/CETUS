"""Reconstruct the five-region paper table from checked policy summaries."""
import companion as c

def table_check(summaries,proof,tex):
    test=summaries['test'];by={(r['fold'],r['initialization']):r for r in test['region_initialization']}
    rows=[]
    for f in range(5):
        row=[by[f,arm]['policies'][policy]['macro_f1']['mean'] for arm in ('scratch','pretrained') for policy in ('selected','epoch100')]
        row.append(row[3]-row[1]);rows.append(row)
    equal=test['equal_region']
    stats=[equal['policies'][arm][policy]['macro_f1'] for arm in ('scratch','pretrained') for policy in ('selected','epoch100')]
    stats.append(equal['pretrained_minus_scratch']['epoch100']['macro_f1'])
    means=[v['mean'] for v in stats];sds=[v['sample_sd'] for v in stats]
    for name,actual in [('rows',rows),('means',means),('sample_sds',sds)]:c.equal(proof[name],actual,'Paper table '+name)
    c.need(c.nm.sha(tex)==proof['table_sha256'],'Paper table byte identity')
    text=tex.decode()
    for i,row in enumerate(rows):c.need('Region '+str(i+1)+' & '+' & '.join(f'{100*v:.2f}' for v in row)+' \\\\' in text,'Paper regional formatting')
    c.need(' & '.join(f'${100*a:.2f} \\pm {100*b:.2f}$' for a,b in zip(means,sds)) in text,'Paper mean/SD formatting')
    return {'rows':rows,'means':means,'sample_sds':sds,'table_sha256':proof['table_sha256']}
