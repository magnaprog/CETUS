"""Draft numerical companion projection/checking. No models or archive writer.

Public candidates contain only allowlisted scientific records. Private callers
bind source bytes before projection. An admitted full grid is still required.
"""
import copy
import csv
import gzip
import hashlib
import io
import json
import math
import re
from collections import Counter
from pathlib import Path
import zipfile

import numpy as np
import native_math as nm
import selection_math as sm

DEPENDENCY_SHA = 'ada744e9278f4fbac5f5f953b5688132ad0b080b35cff32ed23b7f02c3192486'
CLASSES = nm.NAMES
need = nm.need
HISTORY_FIELDS = '''cell phase region fold initialization seed initial_lr validation_support
missing_truth_classes accepted_selected_epoch accepted_score eligible_epoch_count tied_maximum_epochs
runner_up_epoch epoch_margin_pp strict_lower_runner_up_epoch strict_lower_margin_pp persistence
last20_validation_score selected_f1_per_class selected_class_contributions_pp selected_tp selected_fp
selected_fn contrasts epoch100_score selected_minus_epoch100_pp class_term_omission single_image_deletion'''.split()
NATIVE_FIELDS = '''balanced_accuracy class_order confusion_matrix f1_per_class false_negative
false_positive kappa labels logits logits_dtype loss loss_denominator loss_numerator macro_f1
precision_per_class predictions probabilities probabilities_dtype probability_argmax_disagreements
recall_per_class support_per_class tile_ids true_positive'''.split()
LABEL_FIELDS = 'tile_id accepted_label weighted_label accepted_name weighted_name center_lat center_lon coverage votes loss_by_class_128_grid_equivalent margin alternatives_match_weighted'.split()
LABEL_SUMMARY_FIELDS = 'cases exact_ties transitions coverage_range baseline_gap_range weighted_gap_range alternate_rule_disagreement_ids'.split()


def loads(raw):
    return json.loads(raw, object_pairs_hook=nm.pairs, parse_float=nm.number, parse_constant=nm.number)


def encode(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False, default=nm.encode)+'\n').encode()


def equal(actual, expected, label='value', atol=1e-15):
    if isinstance(expected, dict):
        need(isinstance(actual, dict) and set(actual) == set(expected), label+': keys')
        for k in expected:
            equal(actual[k], expected[k], label+'/'+k, atol)
    elif isinstance(expected, (list, np.ndarray)):
        need(isinstance(actual, (list, np.ndarray)) and len(actual) == len(expected), label+': length')
        for a,b in zip(actual,expected):
            equal(a,b,label,atol)
    elif isinstance(expected, (float, np.floating)):
        need(type(actual) in (int,float) or isinstance(actual,np.number),label+': numeric type')
        need(math.isfinite(actual) and abs(actual-expected)<=atol,label+': number')
    else:
        if isinstance(expected,np.generic): expected=expected.item()
        if isinstance(actual,np.generic): actual=actual.item()
        need(type(actual) is type(expected) and actual == expected,label+': exact')


def public_text(raw):
    text = raw.decode('utf-8')
    for marker in ('/home/', '/Users/', '/mnt/', '/tmp/', 'GPU-', 'ssh ', 'CUDA_VISIBLE_DEVICES'):
        need(marker not in text, 'Private metadata marker')


def dependency(path):
    raw=Path(path).read_bytes()
    need(nm.sha(raw)==DEPENDENCY_SHA,'Dependency SHA mismatch')
    # Read known entries directly. Never extract or execute ZIP code.
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        need(len(z.namelist())==len(set(z.namelist())),'Duplicate dependency member')
        data=loads(gzip.decompress(z.read('data/records.json.gz')))
        catalog=loads(z.read('data/catalog.json'))
        splits=[loads(z.read(f'data/splits/titan_contiguous_fold_{f}.json')) for f in range(5)]
    need(data['class_order']==catalog['class_names']==CLASSES,'Dependency class order')
    cells={tuple(r['cell']):r for r in data['cells']}
    need(len(cells)==90,'Dependency cell count')
    populations=[]
    for f,s in enumerate(splits):
        population={}
        for role in ('val','test'):
            tiles=[t for t in catalog['tiles'] if s['assignments'][t['tile_id']]==role]
            population[role]={'tile_ids':[t['tile_id'] for t in tiles],'labels':[t['label'] for t in tiles]}
        populations.append(population)
    return {'cells':cells,'populations':populations,'tiles':{r['tile_id']:r for r in catalog['tiles']}}


def project_selection(source, source_sha):
    need(source['schema']=='cetus-selection-stability-v1' and source['status']=='complete','Selection status')
    rows=[]
    for old in source['histories']:
        r={k:copy.deepcopy(old[k]) for k in HISTORY_FIELDS}
        r['result']={'sha256':old['result']['sha256']}
        for omission in r['class_term_omission']: omission.pop('scores_by_epoch')
        rows.append(r)
    rates=copy.deepcopy(source['learning_rates'])
    for r in rates:
        for candidate in r['candidates']: candidate['result']={'sha256':candidate['result']['sha256']}
        for key in ('winner_lrs','winning_candidate_epochs'): r['single_image_deletion'].pop(key)
    result={'schema':'cetus-reassessment-selection-v1','source_sha256':source_sha,
        'histories':rows,'learning_rates':rates,'targets':copy.deepcopy(source['summaries']),
        'deletion_limit':'Counts/regrets reconstructed from supplied outcome ledgers; whole-history deletion scores cannot be recomputed without omitted per-epoch predictions.'}
    public_text(encode(result))
    return result


def deletion_check(saved, labels, support, selected, eligible):
    labels=np.asarray(labels); valid=support[labels]>1; n=int(valid.sum())
    winners=np.asarray(saved['winner_epochs']);best=np.asarray(saved['best_scores']);accepted=np.asarray(saved['accepted_epoch_scores'])
    need(winners.shape==best.shape==accepted.shape==(n,) and winners.dtype.kind in 'iu','Deletion ledger shape/type')
    need(((winners>=1)&(winners<=100)).all() and eligible[winners-1].all(),'Deletion ledger epoch')
    need(np.isfinite(best).all() and np.isfinite(accepted).all() and ((accepted>=0)&(best<=1)&(best>=accepted-1e-14)).all(),'Deletion ledger score')
    need(np.allclose(best[winners==selected],accepted[winners==selected],rtol=0,atol=1e-15),'Unchanged deletion winner score')
    changed=winners!=selected; regret=(best-accepted)*100
    fields={'valid_count':n,'undefined_count':int((~valid).sum()),'switch_count':int(changed.sum()),
        'switch_fraction_of_valid_deletions':float(changed.mean()),
        'winner_epoch_counts':{str(k):v for k,v in sorted(Counter(winners.tolist()).items())},
        'regret_pp':sm.distribution(regret),'regret_pp_by_tile':regret,
        'by_deleted_truth_class':[{'class':name,'valid_count':int(np.sum(labels[valid]==k)),
            'switch_count':int(np.sum(changed & (labels[valid]==k))),'undefined_count':int(np.sum((~valid)&(labels==k)))} for k,name in enumerate(CLASSES)]}
    for key,value in fields.items(): equal(saved[key],value,'deletion/'+key)
    need(saved['array_order']=='fold validation tile_ids restricted to valid_deletion_indices','Deletion ledger order definition')


def history_check(row, old, truth):
    histories=[r['history'] for r in old['validation_history']]
    need([h['epoch'] for h in histories]==list(range(1,101)),'100 ordered epochs required')
    matrices=np.asarray([r['val_confusion_matrix'] for r in histories])
    need(matrices.shape==(100,6,6) and matrices.dtype.kind in 'iu' and (matrices>=0).all(),'History confusion')
    support=np.bincount(truth['labels'],minlength=6)
    need((support>0).all() and (matrices.sum(2)==support).all(),'History supports')
    cf=sm.f1(matrices);scores=np.array([h['val_macro_f1'] for h in histories]);eligible=np.array([h['optimizer_steps']>0 for h in histories])
    nm.numeric(scores,cf.mean(1),'History score reconstruction')
    rank=sorted(np.flatnonzero(eligible),key=lambda i:(-scores[i],i));chosen=rank[0];runner=rank[1]
    strict=next((i for i in rank if scores[i]<scores[chosen]),None)
    need(chosen+1==old['selected_epoch'],'Accepted epoch changed')
    omissions=[]
    for k,name in enumerate(CLASSES):
        v=np.delete(cf,k,axis=1).mean(1);e=max(np.flatnonzero(eligible),key=lambda i:(v[i],-i))
        omissions.append({'omitted_class':name,'diagnostic_epoch':int(e+1),'changed':bool(e!=chosen),
            'five_term_score':v[e],'accepted_epoch_five_term_score':v[chosen],'five_term_gain_pp':(v[e]-v[chosen])*100,
            'original_six_class_score_at_diagnostic_epoch':scores[e]})
    cell=old['cell']; tp=matrices[chosen].diagonal()
    values={'cell':cell,'result':{'sha256':old['result_sha256']},'phase':cell[0],'region':cell[1]+1,'fold':cell[1],
        'initialization':cell[2],'seed':old['seed'],'initial_lr':old['recipe']['lr'],'validation_support':support,
        'missing_truth_classes':[],'accepted_selected_epoch':int(chosen+1),'accepted_score':scores[chosen],
        'eligible_epoch_count':int(eligible.sum()),'tied_maximum_epochs':np.flatnonzero(eligible&(scores==scores[chosen]))+1,
        'runner_up_epoch':int(runner+1),'epoch_margin_pp':(scores[chosen]-scores[runner])*100,
        'strict_lower_runner_up_epoch':int(strict+1) if strict is not None else None,
        'strict_lower_margin_pp':(scores[chosen]-scores[strict])*100 if strict is not None else None,
        'persistence':[sm.persistence(scores,chosen,eligible,d) for d in [0,0.1,0.5,1.0]],
        'last20_validation_score':sm.distribution(scores[-20:]),'selected_f1_per_class':cf[chosen],
        'selected_class_contributions_pp':cf[chosen]*100/6,'selected_tp':tp,'selected_fp':matrices[chosen].sum(0)-tp,
        'selected_fn':matrices[chosen].sum(1)-tp,'contrasts':{name:sm.contrast(cf,chosen,other,scores) for name,other in
          {'runner_up':runner,'previous':chosen-1 if chosen>0 else None,'next':chosen+1 if chosen<99 else None,'epoch100':99}.items()},
        'epoch100_score':scores[-1],'selected_minus_epoch100_pp':(scores[chosen]-scores[-1])*100,'class_term_omission':omissions}
    equal({k:row[k] for k in values},values,'history')
    deletion_check(row['single_image_deletion'],truth['labels'],support,chosen+1,eligible)


def check_selection(projected,dep,tsv):
    rows=projected['histories'];expected={c for c in dep['cells'] if c[0] in ('tuning','final')}
    need(len(rows)==60 and {tuple(r['cell']) for r in rows}==expected,'Selection exact60 grid')
    for row in rows: history_check(row,dep['cells'][tuple(row['cell'])],dep['populations'][row['fold']]['val'])
    rates=loads(encode(sm.rate_analysis(rows)))
    for r in rates:
        for key in ('winner_lrs','winning_candidate_epochs'):r['single_image_deletion'].pop(key)
    equal(projected['learning_rates'],rates,'Rates')
    equal(projected['targets'],sm.summarize(rows,rates),'Selection summary')
    table=list(csv.DictReader(io.StringIO(tsv.decode()),delimiter='\t'));need(len(table)==60,'TSV rows')
    indexed={(r['phase'],r['region'],r['initialization'],r['seed'],r['initial_lr']):r for r in rows}
    seen=set()
    for t in table:
        key=(t['phase'],int(t['region']),t['initialization'],int(t['seed']),float(t['lr']));need(key in indexed and key not in seen,'TSV identity');seen.add(key);r=indexed[key]
        values={'selected_epoch':r['accepted_selected_epoch'],'runner_epoch':r['runner_up_epoch'],'epoch_margin_pp':r['epoch_margin_pp'],
            'within0.5_count':r['persistence'][2]['count'],'within0.5_selected_run':r['persistence'][2]['selected_run_length'],
            'previous_gap_pp':r['contrasts']['previous']['score_difference_pp'] if r['contrasts']['previous'] else None,
            'next_gap_pp':r['contrasts']['next']['score_difference_pp'] if r['contrasts']['next'] else None,
            'selected_minus100_pp':r['selected_minus_epoch100_pp'],'deletion_switch_count':r['single_image_deletion']['switch_count']}
        for k,v in values.items():
            need((t[k] in ('','None') if v is None else math.isfinite(float(t[k])) and abs(float(t[k])-v)<=1e-12),'TSV '+k)
        contributions=r['contrasts']['runner_up']['class_contributions_pp'];i=int(np.argmax(np.abs(contributions)))
        need(t['largest_absolute_runner_class']==CLASSES[i],'TSV largest absolute class')
        equal(float(t['largest_absolute_runner_signed_contribution_pp']),contributions[i],'TSV signed contribution')
    return {'histories':60,'rate_choices':10,'epoch_margin_pp_range':[min(r['epoch_margin_pp'] for r in rows),max(r['epoch_margin_pp'] for r in rows)],
        'margins_at_most_0_1pp':sum(r['epoch_margin_pp']<=.1 for r in rows),
        'histories_with_any_deletion_switch':sum(r['single_image_deletion']['switch_count']>0 for r in rows),
        'rate_choices_with_any_deletion_switch':sum(r['single_image_deletion']['switch_count']>0 for r in rates),
        'whole_history_deletion_recomputed':False}


def project_labels(source,source_sha):
    cases=[]
    for old in source['cases']:
        r={k:copy.deepcopy(old[k]) for k in LABEL_FIELDS}
        r['source_packet']={'path':'cases/'+r['tile_id']+'.npz','sha256':old['source_packet']['sha256']}
        cases.append(r)
    result={'schema':'cetus-reassessment-labels-v1','source_sha256':source_sha,
        'selected_rows_sha256':source['source_selected_rows_sha256'],'cases':cases,
        'targets':{k:copy.deepcopy(source['summary'][k]) for k in LABEL_SUMMARY_FIELDS},
        'scope':'All37 selected case packets. No whole-catalog counts, registration or geological-label correction claim.'}
    public_text(encode(result));return result


def label_summary(projected):
    rows=projected['cases'];ids=[r['tile_id'] for r in rows]
    need(len(ids)==len(set(ids))==37,'Exact37 cases required')
    result={'cases':37,'exact_ties':sum(any(v['is_tie'] for v in r['votes'].values()) for r in rows),
        'transitions':dict(Counter(r['accepted_name']+' -> '+r['weighted_name'] for r in rows)),
        'coverage_range':[min(r['coverage']['fraction'] for r in rows),max(r['coverage']['fraction'] for r in rows)],
        'baseline_gap_range':[min(r['margin']['baseline_top_two_gap_percentage_points'] for r in rows),max(r['margin']['baseline_top_two_gap_percentage_points'] for r in rows)],
        'weighted_gap_range':[min(r['margin']['weighted_top_two_gap_percentage_points'] for r in rows),max(r['margin']['weighted_top_two_gap_percentage_points'] for r in rows)],
        'alternate_rule_disagreement_ids':{m:[r['tile_id'] for r in rows if not r['alternatives_match_weighted'][m]] for m in ('all_four','any_valid')}}
    equal(projected['targets'],result,'Label summary')
    return result


def check_packet(raw,case,tile):
    need(nm.sha(raw)==case['source_packet']['sha256'],'Packet source hash')
    shapes={'sar':('float32',(128,128)),'sar_valid':('bool',(128,128)),
        'map_grid':('uint8',(64,64)),'weights':('uint8',(64,64)),'map_valid':('bool',(64,64))}
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        need(set(z.namelist())=={k+'.npy' for k in shapes} and len(z.namelist())==5,'NPZ members')
        need(not z.comment and all(not i.comment and not i.extra for i in z.infolist()),'NPZ metadata')
        for name in z.namelist():
            member=z.read(name)
            need(member[:6]==b'\x93NUMPY' and member[6:8] in (b'\x01\x00',b'\x02\x00'),'NPY header version')
            start=10 if member[6]==1 else 12
            length=int.from_bytes(member[8:start],'little')
            public_text(member[start:start+length])
    with np.load(io.BytesIO(raw),allow_pickle=False) as z: arrays={k:z[k] for k in z.files}
    for k,(dtype,shape) in shapes.items():
        need(str(arrays[k].dtype)==dtype and arrays[k].shape==shape,'NPZ array schema')
    sar=arrays['sar'];g=arrays['map_grid'];w=arrays['weights'];valid=sar>0
    need(np.isfinite(sar).all() and (sar>=0).all(),'SAR numeric values')
    need(np.array_equal(valid,arrays['sar_valid']) and np.array_equal(arrays['map_valid'],g<6),'Validity masks')
    need(np.array_equal(w,sum(valid[a::2,b::2].astype(np.uint8) for a in range(2) for b in range(2))),'2x2 weights')
    need(set(np.unique(g))<=set(range(6))|{255},'Map class values')
    need(case['tile_id']==tile['tile_id'] and case['accepted_label']==tile['label'],'Catalog label identity')
    equal([case['center_lat'],case['center_lon']],[tile['center_lat'],tile['center_lon']],'Case position')
    votes={}
    for mode,wt in [('baseline',np.ones_like(w)),('weighted',w),('all_four',w==4),('any_valid',w>0)]:
        counts=np.bincount(g[g<6],weights=wt[g<6],minlength=6).astype(int);den=int(counts.sum())
        need(den>0,'Empty vote denominator');winners=np.flatnonzero(counts==counts.max()).tolist()
        votes[mode]={'class_counts':counts.tolist(),'denominator':den,'winner':winners[0],'tied_winners':winners,
            'is_tie':len(winners)>1,'winning_fraction':float(counts.max()/den),'excluded_255_weight':int(wt[g==255].sum()),
            'winning_fraction_4dp':round(float(counts.max()/den),4)}
    equal(case['votes'],votes,'Votes');base=np.array(votes['baseline']['class_counts']);ret=np.array(votes['weighted']['class_counts'])
    old=votes['baseline']['winner'];new=votes['weighted']['winner'];loss=4*base-ret
    need(old!=new and old==case['accepted_label'] and new==case['weighted_label'],'Selected changed-case identity')
    need(case['accepted_name'].lower()==CLASSES[old] and case['weighted_name'].lower()==CLASSES[new],'Case class names')
    equal(votes['baseline']['winning_fraction_4dp'],tile['label_confidence'],'Accepted vote fraction')
    coverage={'valid_pixels':int(valid.sum()),'invalid_pixels':int((~valid).sum()),'total_pixels':16384,'fraction':float(valid.mean()),
        'weight_histogram':np.bincount(w.ravel(),minlength=5).tolist(),'class_retention_fraction':[float(ret[i]/(4*base[i])) if base[i] else None for i in range(6)]}
    equal(case['coverage'],coverage,'Coverage');equal(case['loss_by_class_128_grid_equivalent'],loss,'Vote loss')
    equal(coverage['fraction'],tile['valid_fraction'],'Catalog coverage',atol=0.00005)
    a=int(base[old]-base[new]);b=int(ret[new]-ret[old]);need(int(loss[old]-loss[new])-4*a==b,'Vote loss identity')
    margins={'baseline_old_minus_new_map_votes':a,'weighted_new_minus_old_units':b,'loss_old_minus_new_units':int(loss[old]-loss[new]),
        'baseline_top_two_gap_votes':int(np.sort(base)[-1]-np.sort(base)[-2]),'weighted_top_two_gap_units':int(np.sort(ret)[-1]-np.sort(ret)[-2]),
        'baseline_top_two_gap_percentage_points':float(100*(np.sort(base)[-1]-np.sort(base)[-2])/base.sum()),
        'weighted_top_two_gap_percentage_points':float(100*(np.sort(ret)[-1]-np.sort(ret)[-2])/ret.sum()),
        'identity':'weighted[new]-weighted[old] = loss[old]-loss[new] - 4*(baseline[old]-baseline[new])'}
    equal(case['margin'],margins,'Margins')
    equal(case['alternatives_match_weighted'],{m:votes[m]['winner']==new for m in ('all_four','any_valid')},'Alternate votes')
    return {'tile_id':case['tile_id'],'source_sha256':nm.sha(raw),'vote_records':4,'exact_ties':sum(v['is_tie'] for v in votes.values())}


def project_native(receipt,source_sha,old,epoch):
    need(receipt['schema']=='cetus-final-epoch-result-v1' and receipt['status']=='complete','Native status')
    c=receipt['cell'];e=receipt['evaluation'];cell=c['cell']
    need(['final',*cell]==old['cell'] and c['result']['sha256']==old['result_sha256'],'Original result identity')
    need(e['epoch']==100 and e['exact_validation'] is True and e['test_calls']==1,'Native epoch/equality flags')
    equal(e['original_selected_test'],old['test'],'Original selected test',atol=0)
    equal(e['validation'],epoch['validation'],'Saved epoch100 validation',atol=0)
    equal(epoch['history'],old['validation_history'][-1]['history'],'Saved epoch100 history',atol=0)
    need(e['epoch_record']['sha256']==c['epoch100_sha256']==old['validation_history'][-1]['source_epoch_sha256'],'Epoch source identity')
    need(e['state_sha256']==c['final_state_sha256']==old['final_state_sha256'],'Final state identity')
    need(e['original_selected_state_sha256']==old['selected_state_sha256'],'Selected state identity')
    need(e['original_selected_epoch']==c['selected_epoch']==old['selected_epoch'] and c['lr']==old['recipe']['lr'],'Selected epoch/rate identity')
    need(e['final_checkpoint']['sha256']==c['final_sha256'],'Final checkpoint identity')
    need(set(e['validation'])==set(e['test'])==set(NATIVE_FIELDS),'Native evaluation schema')
    producer=receipt['driver_producer']
    need(re.fullmatch('[0-9a-f]{40}',producer['commit']) is not None,'Producer commit identity')
    need(all(re.fullmatch('[A-Za-z0-9_]+\\.py',name) and re.fullmatch('[0-9a-f]{64}',sha)
             for name,sha in producer['files'].items()),'Producer file identities')
    result={'cell':cell,'source_sha256':source_sha,'original_result_sha256':old['result_sha256'],
        'producer_commit':producer['commit'],'producer_file_sha256':copy.deepcopy(producer['files']),
        'selected_epoch':old['selected_epoch'],'lr':c['lr'],'selected_state_sha256':old['selected_state_sha256'],
        'final_state_sha256':old['final_state_sha256'],'final_checkpoint_sha256':c['final_sha256'],
        'epoch_record_sha256':c['epoch100_sha256'],'original_selected_test_digest':nm.digest(old['test']),
        'exact_saved_validation_digest':nm.digest(epoch['validation']),
        'validation':copy.deepcopy(e['validation']),'test':copy.deepcopy(e['test'])}
    public_text(encode(result));return result


def selected_validation_metrics(old,truth):
    record=old['validation_history'][old['selected_epoch']-1];cm=np.asarray(record['history']['val_confusion_matrix'])
    need(cm.shape==(6,6) and cm.dtype.kind in 'iu' and (cm>=0).all(),'Selected validation confusion')
    support=cm.sum(1);predicted=cm.sum(0);tp=cm.diagonal();n=int(support.sum())
    need(np.array_equal(support,np.bincount(truth['labels'],minlength=6)) and (support>0).all(),'Selected validation support')
    expected=int(np.dot(support,predicted));need(n*n>expected,'Selected kappa denominator')
    precision=np.divide(tp,predicted,out=np.zeros(6),where=predicted>0);recall=tp/support;f1=2*tp/(support+predicted)
    result={'macro_f1':float(f1.mean()),'balanced_accuracy':float(recall.mean()),'kappa':float((n*int(tp.sum())-expected)/(n*n-expected)),
        'precision_per_class':precision.tolist(),'recall_per_class':recall.tolist(),'f1_per_class':f1.tolist(),'support_per_class':support.tolist()}
    for key,value in result.items():equal(record['metrics'][key],value,'Selected validation '+key)
    return result


def check_native(row,dep):
    cell=nm.identity(row['cell']);old=dep['cells'][('final',*cell)];truth=dep['populations'][cell[0]]
    need(row['original_result_sha256']==old['result_sha256'] and row['selected_epoch']==old['selected_epoch']
         and row['lr']==old['recipe']['lr'] and row['selected_state_sha256']==old['selected_state_sha256']
         and row['final_state_sha256']==old['final_state_sha256'],'Cell dependency bindings')
    need(row['epoch_record_sha256']==old['validation_history'][-1]['source_epoch_sha256'],'Epoch100 source SHA')
    need(row['original_selected_test_digest']==nm.digest(old['test']) and row['exact_saved_validation_digest']==nm.digest(row['validation']),'Native equality digest')
    roles={}
    for role,native_role in [('validation','val'),('test','test')]:
        saved=row[role];need(set(saved)==set(NATIVE_FIELDS),'Native fields')
        new=nm.native_metrics(saved,truth[native_role])
        selected=nm.native_metrics(old['test'],truth['test']) if role=='test' else selected_validation_metrics(old,truth['val'])
        roles[native_role]={'selected':selected,'epoch100':new}
    for key in ('macro_f1','confusion_matrix','loss','loss_numerator','loss_denominator'):
        equal(row['validation'][key],old['validation_history'][-1]['history']['val_'+key],'Epoch100 history '+key,atol=0)
    return {'cell':list(cell),'roles':roles}


def check_full_grid(rows,dep,targets):
    nm.complete_grid(rows)
    records=[check_native(row,dep) for row in rows]
    summaries={role:nm.aggregate(records,role) for role in ('val','test')}
    equal(summaries,targets,'Prospective policy summaries')
    return summaries


def admission_gate(acceptance,contract_sha,outputs,numerical_review_sha):
    """A parent admission is separate from prospective numerical success."""
    need(acceptance.get('status')=='accepted_for_numeric_packaging' and acceptance.get('scope')=='full_grid',
         'Explicit parent all30 admission required')
    need(acceptance.get('contract_sha256')==contract_sha and acceptance.get('numerical_review_sha256')==numerical_review_sha,
         'Parent acceptance bindings differ')
    nm.complete_grid(outputs)
    bindings=[{'cell':r['cell'],'sha256':r['sha256']} for r in outputs]
    need(acceptance.get('outputs')==bindings,'Parent exact30 output bindings differ')
    need(len({r['sha256'] for r in outputs})==30,'Repeated output source SHA')
