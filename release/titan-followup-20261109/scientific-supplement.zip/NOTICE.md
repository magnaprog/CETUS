The author-owned review copy temporarily withholds the author's copyright name
for anonymous assessment. The public license is unchanged. Third-party notices
and the CROMA license are retained verbatim; their named authors are not removed.

Catalog and five fold manifests preserve the existing sanitized release bytes.
The native execution catalog has a different hash because its private paths and
legacy split fields were omitted in that prior export. Original execution
identities must not be relabeled as a fresh public-input run.

This copy removes five absolute split-source paths from the common summary,
private acceptance/source bindings from the scaling aggregate, and nonessential
execution/source/environment routing from the 80 individual fit records.
Saved numerical arrays are byte-identical, including probabilities, labels,
predictions and IDs. Retained JSON numerical values and types are unchanged.
The partial-training JSON selects the 75 existing adaptation test records;
validation and training-substitution records are omitted. No scientific values
or labels were corrected. Other shared prediction files retain some controls
that the minimal consumer does not evaluate.

The metric consumer is newly packaged from the existing six-class count/ratio
arithmetic. It is not the original private acceptance harness. The identical
consumer and scientific files passed independent extracted-v2 tests, as
described in README.md. V3 changes documentation, the singular anonymous
author attribution, and the resulting inventories only. Those tests do not
establish full image/inference reproduction or scientific publication approval.
The source-to-package mapping and exact field-removal record are retained
privately and are not included in this archive.
