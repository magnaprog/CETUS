"""Recompute saved-prediction metrics. No training, inference, or feature loading."""
import argparse
import gzip
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np

MODELS = ('dinov2', 'dofa', 'croma', 'random_init')
CLASSICAL = ('raw_intensity_statistics', 'intensity_histogram',
             'texture_glcm_lbp_gabor_hog_wavelet', 'combined_classical')
CLASSES = ('plains', 'dunes', 'hummocky', 'labyrinths', 'lakes', 'craters')
METRICS = ('precision', 'recall', 'f1')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    with (gzip.open(path, 'rt') if str(path).endswith('.gz') else path.open()) as stream:
        return json.load(stream)


def exact(actual, expected, label):
    require(np.array_equal(actual, expected), label)


def close(actual, expected, label):
    a, b = np.asarray(actual), np.asarray(expected)
    require(a.shape == b.shape and np.isfinite(a).all() and np.isfinite(b).all()
            and np.allclose(a, b, rtol=0, atol=1e-12), label)


def metrics(y, p):
    # Same six-class count/ratio arithmetic as the retained saved-state checker.
    y, p = np.asarray(y), np.asarray(p)
    require(y.ndim == p.ndim == 1 and y.shape == p.shape, 'Prediction shape')
    require(y.dtype.kind in 'iu' and p.dtype.kind in 'iu', 'Integer classes required')
    require(np.isin(y, range(6)).all() and np.isin(p, range(6)).all(), 'Class range')
    cm = np.zeros((6, 6), np.int64)
    np.add.at(cm, (y, p), 1)
    a, b, h = cm.sum(1), cm.sum(0), cm.diagonal()
    result = {'confusion': cm.tolist(), 'support': a.tolist(), 'predicted_counts': b.tolist()}
    for name, numerator, denominator in [('precision', h, b), ('recall', h, a),
                                          ('f1', 2 * h, a + b)]:
        value = np.divide(numerator, denominator, out=np.zeros(6), where=denominator != 0)
        result[name] = value.tolist()
        result['macro_' + name] = float(value.mean())
    return result


def grid(rows, fields, expected, label):
    result = {tuple(row[field] for field in fields): row for row in rows}
    require(len(result) == len(rows) and set(result) == set(expected), label)
    return result


def spread(values):
    values = np.asarray(values, dtype=np.float64)
    require(values.shape[0] == 5 and np.isfinite(values).all(), 'Five finite folds required')
    return values.mean(axis=0), values.std(axis=0, ddof=1)


def check_summary(values, target, label, fold_key='fold_values', sd_key='sample_std'):
    mean, sd = spread(values)
    close(values, target[fold_key], label + ' folds')
    close(mean, target['mean'], label + ' mean')
    close(sd, target[sd_key], label + ' SD')


def check_counts(score, target, label, native=False):
    exact(score['confusion'], target['confusion_counts' if native else 'confusion'], label + ' confusion')
    exact(score['support'], target['support'], label + ' support')
    exact(score['predicted_counts'], target['prediction_counts' if native else 'predicted_counts'], label + ' predicted')
    for metric in METRICS:
        close(score[metric], target['per_class'][metric] if native else target[metric], label + ' ' + metric)
        close(score['macro_' + metric], target['macro'][metric] if native else target['macro_' + metric], label + ' macro ' + metric)


def verify_manifest(root):
    manifest = read(root / 'manifest.json')
    expected = set(manifest['files'])
    actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
    require(actual == expected | {'manifest.json', 'SHA256SUMS'}, 'Package inventory differs')
    require(not any(p.is_symlink() for p in root.rglob('*')), 'Symlink in package')
    for name, row in manifest['files'].items():
        path = root / name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe member path')
        require(path.stat().st_size == row['bytes'], 'Size differs: ' + name)
        with path.open('rb') as stream:
            require(hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256'], 'Hash differs: ' + name)
    checksum_rows = [line.split('  ', 1) for line in (root / 'SHA256SUMS').read_text().splitlines()]
    require(all(len(row) == 2 for row in checksum_rows), 'Malformed checksum row')
    checksum_names = [name for _, name in checksum_rows]
    require(len(checksum_names) == len(set(checksum_names)), 'Duplicate checksum member')
    require(set(checksum_names) == expected | {'manifest.json'}, 'Incomplete checksum inventory')
    for expected_hash, name in checksum_rows:
        with (root / name).open('rb') as stream:
            require(hashlib.file_digest(stream, 'sha256').hexdigest() == expected_hash, 'Checksum differs: ' + name)


def replay(root):
    verify_manifest(root)
    catalog = read(root / 'data/catalog.json')
    require(tuple(catalog['class_names']) == CLASSES, 'Catalog class order')
    tiles = catalog['tiles']
    require(len(tiles) == len({t['tile_id'] for t in tiles}) == 23380, 'Catalog population')
    common = read(root / 'audit/common_classifier_20260930/COMMON_CLASSIFIER_RESULTS_2026-09-29.json')
    frozen = read(root / 'results/frozen_results.json')
    lr = grid(read(root / 'results/common_predictions.json.gz')['folds'], ('fold',), [(f,) for f in range(5)], 'LR grid')
    saved_frozen = grid(read(root / 'results/frozen_predictions.json.gz')['jobs'], ('model', 'fold'), itertools.product(MODELS, range(5)), 'Frozen grid')
    ft = grid(read(root / 'results/partial_training_predictions.json.gz')['test'], ('model', 'fold', 'seed'), itertools.product(MODELS[:3], range(5), range(5)), 'Partial-training grid')
    truths, orders, seen = {}, {}, set()
    catalog_hash = hashlib.sha256((root / 'data/catalog.json').read_bytes()).hexdigest()
    for fold in range(5):
        split = read(root / f'data/splits/titan_contiguous_fold_{fold}.json')
        require(split['catalog_sha256'] == catalog_hash, 'Split/catalog hash')
        require(set(split['assignments']) == {t['tile_id'] for t in tiles}, 'Split ID coverage')
        selected = [t for t in tiles if split['assignments'][t['tile_id']] == 'test']
        ids, truth = [t['tile_id'] for t in selected], [t['label'] for t in selected]
        require(not seen.intersection(ids), 'Test overlap')
        seen.update(ids)
        orders[fold], truths[fold] = ids, truth
        exact(lr[fold,]['test_ids'], ids, 'Common ID order')
        exact(lr[fold,]['true_labels'], truth, 'Common labels')
    require(len(seen) == 23246, 'Test union')

    lr_scores, sgd_scores, ft_scores, knn_scores = {}, {}, {}, {}
    for family in MODELS + CLASSICAL:
        target = common['joint_fixed_classifier']['families'][family]
        folds = grid(target['folds'], ('fold',), [(f,) for f in range(5)], 'Common target grid')
        scores = []
        for fold in range(5):
            pred = lr[fold,]['common' if family in MODELS else 'classical'][family]
            score = metrics(truths[fold], pred)
            check_counts(score, folds[fold,], family + str(fold), native=True)
            scores.append(score)
        lr_scores[family] = scores
        for metric in METRICS:
            check_summary([s['macro_' + metric] for s in scores], target['macro'][metric], family + metric)

    for model in MODELS:
        targets = grid(frozen['models'][model]['folds'], ('fold',), [(f,) for f in range(5)], 'Frozen target grid')
        heads_by_fold, neighbors_by_fold = [], []
        for fold in range(5):
            saved = saved_frozen[model, fold]
            exact(saved['tile_ids'], orders[fold], 'Frozen ID order')
            exact(saved['true_labels'], truths[fold], 'Frozen labels')
            exact(saved['seeds'], list(range(5)), 'Frozen seeds')
            require(len(saved['probe_predictions']) == 5, 'Five SGD heads')
            heads = [metrics(truths[fold], pred) for pred in saved['probe_predictions']]
            expected_heads = grid(targets[fold,]['probe_heads'], ('seed',), [(s,) for s in range(5)], 'Head target grid')
            for seed, score in enumerate(heads):
                check_counts(score, expected_heads[seed,], 'SGD head', native=True)
            neighbor = metrics(truths[fold], saved['knn_predictions'])
            check_counts(neighbor, targets[fold,]['knn'], 'kNN', native=True)
            heads_by_fold.append({k: np.mean([s[k] for s in heads], axis=0) for k in ('macro_precision', 'macro_recall', 'macro_f1', *METRICS)})
            neighbors_by_fold.append(neighbor)
        sgd_scores[model], knn_scores[model] = heads_by_fold, neighbors_by_fold
        for metric in METRICS:
            check_summary([s['macro_' + metric] for s in heads_by_fold], common['models'][model]['original']['macro'][metric], model + ' SGD ' + metric)

    display = read(root / 'paper/figure_data/repaired/adaptation_display.json')
    macro_rows = grid(
        [{**row, 'model_key': row['model'].lower()} for row in display['macro_rows']],
        ('model_key',), [(m,) for m in MODELS[:3]], 'Three-model display macro grid')
    class_rows = grid(
        [{**row, 'model_key': row['model'].lower(), 'class_key': row['terrain_class'].lower()}
         for row in display['class_rows']],
        ('model_key', 'class_key'), itertools.product(MODELS[:3], CLASSES),
        'Eighteen-row display class grid')
    for model in MODELS[:3]:
        folds = []
        for fold in range(5):
            scores = [metrics(truths[fold], ft[model, fold, seed]['predictions']) for seed in range(5)]
            folds.append({k: np.mean([s[k] for s in scores], axis=0) for k in ('macro_precision', 'macro_recall', 'macro_f1', *METRICS)})
        ft_scores[model] = folds
        row = macro_rows[model,]
        for metric in ('f1', 'recall'):
            mean, sd = spread([s['macro_' + metric] for s in folds])
            close(100 * mean, row['ft_' + metric + '_mean'], 'FT macro mean')
            close(100 * sd, row['ft_' + metric + '_sample_std'], 'FT macro SD')
        for class_id, name in enumerate(CLASSES):
            row = class_rows[model, name]
            for method, scores in [('ft', folds), ('lr', lr_scores[model])]:
                for metric in METRICS:
                    mean, sd = spread([s[metric][class_id] for s in scores])
                    close(100 * mean, row[method + '_' + metric + '_mean'], 'Class mean')
                    close(100 * sd, row[method + '_' + metric + '_sample_std'], 'Class SD')

    index = read(root / 'results/scaling/index.json')
    expected = set(itertools.product(MODELS, range(5), (False, True), ('none', 'l2')))
    cells = grid(index['cells'], ('model', 'fold', 'standardize', 'regularization'), expected, '80-fit grid')
    sensitivity = read(root / 'audit/fitting_20261106/results.json')
    settings = grid(sensitivity['settings'], ('model', 'standardize', 'regularization'), itertools.product(MODELS, (False, True), ('none', 'l2')), '16-setting grid')
    test_scores = {}
    for key, cell in cells.items():
        model, fold, standardize, regularization = key
        directory = root / 'results/scaling' / cell['id']
        record = read(directory / 'result.json')
        require(record['cell'] == cell, 'Cell metadata')
        with (directory / 'fitted_arrays.npz').open('rb') as stream:
            require(hashlib.file_digest(stream, 'sha256').hexdigest() == record['arrays_sha256'], 'Cell arrays hash')
        with np.load(directory / 'fitted_arrays.npz', allow_pickle=False) as arrays:
            exact(arrays['classes'], list(range(6)), 'Fit class order')
            exact(arrays['test_ids'], orders[fold], 'Fit test IDs')
            exact(arrays['test_labels'], truths[fold], 'Fit test labels')
            score = metrics(arrays['test_labels'], arrays['test_predictions'])
        check_counts(score, record['test'], '80-fit saved metrics')
        test_scores[key] = score
    for key, setting in settings.items():
        model, standardize, regularization = key
        scores = [test_scores[model, f, standardize, regularization] for f in range(5)]
        for metric in (*METRICS, 'macro_precision', 'macro_recall', 'macro_f1'):
            check_summary([s[metric] for s in scores], setting['test'][metric], 'Scaling ' + metric, 'folds_1_to_5', 'sample_sd')
        exact([s['confusion'] for s in scores], setting['test']['confusion_by_fold'], 'Scaling fold counts')
    terms = {
        'standardized_minus_raw_at_no_penalty': [(True, 'none', 1), (False, 'none', -1)],
        'standardized_minus_raw_at_l2': [(True, 'l2', 1), (False, 'l2', -1)],
        'l2_minus_no_penalty_raw': [(False, 'l2', 1), (False, 'none', -1)],
        'l2_minus_no_penalty_standardized': [(True, 'l2', 1), (True, 'none', -1)],
        'difference_of_differences': [(True, 'l2', 1), (True, 'none', -1), (False, 'l2', -1), (False, 'none', 1)],
    }
    differences = grid(sensitivity['differences'], ('model', 'comparison'), itertools.product(MODELS, terms), '20-contrast grid')
    for (model, name), row in differences.items():
        for metric in (*METRICS, 'macro_precision', 'macro_recall', 'macro_f1'):
            values = [sum(sign * np.asarray(test_scores[model, f, scale, reg][metric]) for scale, reg, sign in terms[name]) for f in range(5)]
            check_summary(values, row['test'][metric], 'Scaling contrast', 'folds_1_to_5', 'sample_sd')
    return {'status': 'pass', 'scope': 'Saved test-prediction metrics and accepted summaries; no inference, training, feature-to-probability replay, gradient recomputation or optimum claim.',
            'checks': {'catalog_tiles': 23380, 'test_union': 23246, 'common_lr_vectors': 40,
                       'sgd_vectors': 100, 'knn_vectors': 20, 'partial_training_vectors': 75,
                       'scaling_cells': 80, 'scaling_settings': 16, 'scaling_contrasts': 20},
            'numeric_tolerance': 'IDs, labels and integer counts exact; derived metrics and spreads absolute tolerance 1e-12, no relative tolerance.',
            'excluded': ['training replay', 'probability reconstruction', 'gradient diagnostics', 'image accessibility', 'geological validation', 'all supplementary analyses']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='Optional new JSON file outside the package')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    if args.output:
        require(not args.output.resolve().is_relative_to(root), 'Output must be outside package')
        require(not args.output.exists(), 'Output already exists')
    result = replay(root)
    text = json.dumps(result, indent=2, allow_nan=False) + '\n'
    if args.output:
        with args.output.open('x') as stream:
            stream.write(text)
    print(text, end='')


if __name__ == '__main__':
    main()
