This anonymous local supplement contains saved results for the current Titan
geographic map-agreement evaluation. It is prepared for review and has not been
submitted. Its metric/table code and scientific files are unchanged from
the independently tested extracted package v2.

Scope: the 23,380-tile current catalog, five geographic splits (23,246 unique
test tiles), common LR/classical, seeded SGD, kNN and partial-training saved
predictions; all 80 returned fitting-study arrays and numerical records; eleven
table inputs and their generator; and exact reference adapters/configuration.
The 80-fit study is an additional study beyond the earlier saved predictions.
Historical 11,371-tile results, Earth/Venus evaluations and old CNN runs are out
of scope. No label change was made. A separate reconstruction of the label
raster differed at seven cells; this package retains the accepted catalog
and predictions. Neither raster is included. See supplementary manuscript
for the separate label checks.

Images, raw mosaics/map rasters, embeddings, encoder weights and trained encoder
checkpoints are absent. This is not image-to-result or training reproduction.
The reference source is supplied for inspection, not as runnable inference.
No processed-image download endpoint is supplied. Primary source-product links
below do not deliver the exact processed benchmark arrays.

After inspecting scripts/replay_metrics.py, a reviewer can use Python 3.12.3 and
NumPy 2.4.4 (the recorded numerical versions). No other Python package is needed.
Install NumPy in an external environment if needed; do not install this directory
as the full project. Running offline is possible once NumPy is available.

From the extracted package root, the intended commands are:

```sh
python3 -B scripts/replay_metrics.py --output ../saved-metric-replay.json
python3 -B scripts/prepare_cvpr_tables.py --output paper/cvpr2027/tables --check
```

The first command checks hashes,
catalog/split membership and saved test-prediction metrics; it writes only the
specified new report outside the package. Omitting --output prints the report.
The second checks all eleven existing generated TeX table fragments using only
the standard library. It neither rebuilds PDFs nor fits a classifier.

Independent checks of extracted v2 passed for 315 saved test-prediction
vectors, including all 80 fitting-study cells, sixteen settings and twenty
scaling/penalty contrasts. All eleven table-input checks passed. Negative
controls rejected a changed common prediction after integrity metadata was
refreshed, a duplicated fitting cell, a duplicated display model row, and
an omitted checksum entry. The tested v2 ZIP SHA256 is
95604ca9117cbe09c38e7a3669c76c534fac6bfb7588e2350a4bc1ccd2b08a65.
V3 changes only documentation, the anonymous author attribution, and the
resulting inventories. Its final archive identity and final extracted-package
replay are recorded separately. The v2 checks establish saved-result
reconstruction within this scope; they are not scientific publication
approval or image-to-result reproduction.

Common LR supplies the eight-family comparison in the main feature table
(Table 1). The consumer reconstructs six-class confusion counts, precision,
recall and F1, with zero for undefined ratios. It averages each metric within
the five SGD or partial-training seeds, then equally across five regions, using
sample SD (ddof=1). kNN has one vector per model/fold. Counts, IDs and labels
must match exactly; derived metric/spread comparisons use absolute tolerance
1e-12 and no relative tolerance. The 80-fit path checks saved test predictions,
all sixteen settings and twenty scaling/penalty contrasts. Its arrays retain
training predictions/probabilities/coefficients, but those are not reconstructed
by this consumer. It does not refit scaling parameters, recalculate gradients,
or evaluate features through coefficients. Twenty-four saved encoder contrasts
and all supplementary claims are outside its independent calculation scope.

The reported numerical warnings remain: 23 iteration caps and 54 recorded
gradient concerns. The package preserves these records, not a convergence proof.
Fold spreads are descriptive. Scores measure agreement with SAR-informed map
labels, not independent geological accuracy or an isolated pretraining effect.
DOFA's input/checkpoint correspondence remains unresolved.

data/catalog.json is the prior sanitized catalog. Its SHA256 is
8152226f876e0cb5fad105e0b00a37ef5b62d156d7f6eb3a85b77c549a402967.
The five splits bind that exact file. Class order is Plains, Dunes, Hummocky,
Labyrinths, Lakes, Craters (0 through 5). Catalog order determines each fold's
prediction order. Map votes are not intersected with SAR validity; a modal label
can describe terrain absent from the observed image. Raw fill values and valid
low image values can both become zero after normalization. Fold-specific
normalization records are retained in results/frozen_results.json; reference
dataset source describes the transformation. Catalog VIMS fields are display
samples, not classifier features or calibrated composition measurements.

Primary image/label source references (third-party only):

- USGS Astrogeology, Cassini SAR HiSAR Global Mosaic 351 m:
  https://astrogeology.usgs.gov/search/map/titan_cassini_sar_hisar_global_mosaic_351m
  Attribute the Cassini SAR Team, JPL and USGS Astrogeology. This source record
  identifies the mosaic; it is not an anonymous processed-tile archive.
- Titan Global Map Shapefiles, version 1, Ashley Schoenfeld, corresponding to
  Lopes et al. (2020): https://data.mendeley.com/datasets/f6jrtyfp66/1
  DOI 10.17632/f6jrtyfp66.1; CC BY 4.0.
- VIMS/ISS mosaic record for retained ancillary catalog fields:
  https://data.caltech.edu/records/8q9an-yt176 ; DOI 10.22002/D1.1173.
  Preserve the BSD notice in THIRD_PARTY_NOTICES.md.

DATA_LICENSES.md and THIRD_PARTY_NOTICES.md retain the existing source notices
verbatim, including notices for additional source products absent here. LICENSE
covers author-owned code with attribution temporarily withheld; the separate
CROMA notice is unchanged. NumPy is an installed dependency, not redistributed
inside this ZIP. No third-party encoder weights or external source trees are
copied. Manifest and checksum files cover this package; no private source paths
or author repository link is supplied.
