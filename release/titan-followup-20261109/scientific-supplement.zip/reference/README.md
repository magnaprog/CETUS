These four source files are exact accepted feature-producer bytes for the loader,
configuration, wrappers and local CROMA implementation. They are reference code
for inspection, not an installable inference/training package. Their local hashes
are in manifest.json. Do not execute them as part of metric replay.

The reference code imports NumPy/PyTorch; CROMA also uses einops; optional model
loading uses timm and Torch Hub. None is needed for the metric-only consumer
except NumPy. Encoder source and weights are not bundled. Upstream references:

- DINOv2: https://github.com/facebookresearch/dinov2/tree/7764ea0f912e53c92e82eb78a2a1631e92725fc8
- DOFA: https://github.com/zhu-xlab/DOFA/tree/73ff5c0721da322689ae890bed5b4efd78935f47
- CROMA: https://github.com/antofuller/CROMA

DOFA's numeric 13.78 input conditions its learned patch embedding; no physical
frequency-to-wavelength conversion is implemented. Its checkpoint/input contract
remains unresolved. This package does not choose a replacement identifier.
CROMA's repeated channels are copies of the same SAR image.

Checkpoint filenames: dinov2_vitb14_pretrain.pth, DOFA_ViT_base_e100.pth,
CROMA_base.pt. Their recorded identities are in checkpoint-identities.json;
weights were neither copied nor freshly rehashed for this package. The vendored
CROMA source keeps its upstream license in licenses/CROMA-LICENSE at package root.
