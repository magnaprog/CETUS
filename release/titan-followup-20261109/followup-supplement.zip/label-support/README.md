This bundle replays saved SAR label-support votes. It contains the 2,685-tile vote packet, results and selection, sixty original SAR inspection packets, the empty decoder log, and an independent NumPy checker. It performs no new map sampling, training or inference.

With Python and NumPy installed, run from this directory:

```sh
python -B replay_vote_inputs.py data --report NEW_RECEIPT.json \
  --expect-manifest-sha256 be98e9950e19641889e8e8234a43b3b2913648848407df38796fc58b9e556e69
```

Use a new receipt filename. Exit zero means all vote fields, summaries, sixty saved SAR masks/weights/map grids, and manifest-listed hashes agree. The checker is unchanged from the independent original-output review.

`packaging_manifest.json` links original and remapped metadata digests. All 65 original output files are represented: **64 are byte-identical**, including every scientific result, selection and NPZ file; `bindings.json` is remapped metadata. `run_manifest.json` also has a new digest. Both explicitly identify themselves as projections. Their completion status, timestamps, actual producer commit and recorded clean Git state describe the historical run. No original checkout was recreated, and the remapped producer command was not executed.

Private input, executable and source locations use logical names. Source and input content digests are preserved. `excluded-inputs/` entries are identifiers, not supplied files: the complete tile archive, catalog, coverage ledger, native archive manifest and reference TIFF are excluded. Original producer source files and its full environment are also absent. The recorded producer fingerprints remain provenance identifiers, not a recreated executable history.

Replay verifies integer accounting and consistency of saved inspection data. Accepted labels come from the bound results. It does not independently authenticate the full archive/catalog, resample the TIFF, establish exact SAR/map registration or physical area, or measure geological accuracy or model performance. Nominal 2×2 correspondence remains approximate. `validation/` retains the packaging replay and verification evidence.
