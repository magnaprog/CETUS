#!/usr/bin/env python3
"""Replay a completed label-support output bundle using NumPy and the stdlib.

No producer imports, input TIFFs, original archives, geospatial libraries or
models are used. All paths are supplied at the command line. The output receipt
must be new and outside the input bundle. Published output hashes are verified
before and after replay; accepted labels are taken from the bound result rows.
"""

import argparse
import hashlib
import json
import math
import platform
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import numpy as np


COEFFICIENTS = {
    "baseline": (1, 1, 1, 1, 1),
    "weighted": (0, 1, 2, 3, 4),
    "all_four": (0, 0, 0, 0, 1),
    "any_valid": (0, 1, 1, 1, 1),
}
LIMITS = [
    "Replays saved integer vote inputs; does not resample or validate source TIFF geometry.",
    "Raw saved SAR consistency is checked only for the inspection packets, not every sampled tile.",
    "Accepted labels/fractions are the bound result metadata, not a fresh catalog authentication.",
    "Archive-wide authentication is the producer's recorded claim, not independently repeated here.",
    "Nominal 2x2 support is approximate; no exact co-registration, physical area, geological accuracy or model-performance claim.",
    "Integrity hashes establish the reviewed output bytes, not an external signature or scientific acceptance.",
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, f"Duplicate JSON key: {key}")
            result[key] = value
        return result

    def invalid(value):
        raise ValueError(f"Nonfinite JSON: {value}")

    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs, parse_constant=invalid)


def equal(actual, expected, location):
    """Exact recursive equality, including bool versus integer field types."""
    require(type(actual) is type(expected), f"{location}: type {type(actual).__name__}, expected {type(expected).__name__}")
    if isinstance(expected, dict):
        require(actual.keys() == expected.keys(), f"{location}: keys differ")
        for key in expected:
            equal(actual[key], expected[key], f"{location}.{key}")
    elif isinstance(expected, list):
        require(len(actual) == len(expected), f"{location}: length differs")
        for index, (left, right) in enumerate(zip(actual, expected)):
            equal(left, right, f"{location}[{index}]")
    else:
        require(actual == expected, f"{location}: {actual!r} != {expected!r}")


def member_path(root, name):
    require(isinstance(name, str), "Non-string output name")
    relative = PurePosixPath(name)
    require(not relative.is_absolute() and str(relative) == name
            and all(part not in ("", ".", "..") for part in relative.parts),
            f"Unsafe output name: {name}")
    path = root.joinpath(*relative.parts)
    require(path.resolve().is_relative_to(root), f"Output escapes bundle: {name}")
    require(not path.is_symlink() and path.is_file(), f"Missing or symlinked output: {name}")
    return path


def arrays(path, names):
    with zipfile.ZipFile(path) as archive:
        members = archive.namelist()
        require(len(members) == len(set(members)), f"Duplicate NPZ member: {path.name}")
        require(set(members) == {name + ".npy" for name in names}, f"Unexpected NPZ keys: {path.name}")
    with np.load(path, allow_pickle=False) as packet:
        return {name: packet[name] for name in names}


def replay_grid(grid, weights):
    """Use an integer 7-label by 5-weight contingency table, then dot products.

    Label six is a local bin for nodata. This differs from the producer's
    per-class boolean mask summations. Every cell enters exactly one joint bin.
    """
    require(grid.shape == weights.shape == (64, 64), "Vote array shape")
    require(grid.dtype == weights.dtype == np.dtype("uint8"), "Vote array dtype")
    require(np.all((grid <= 5) | (grid == 255)), "Invalid map label")
    require(np.all(weights <= 4), "Invalid support weight")
    labels = grid.astype(np.int64).ravel()
    labels[labels == 255] = 6
    codes = labels * 5 + weights.astype(np.int64).ravel()
    table = np.bincount(codes, minlength=35).reshape(7, 5)
    histogram = table.sum(axis=0).tolist()
    require(sum(histogram) == 4096, "Grid partition is incomplete")
    valid_pixels = sum(weight * number for weight, number in enumerate(histogram))
    votes = {}
    for mode, coefficients in COEFFICIENTS.items():
        totals = (table @ np.asarray(coefficients, dtype=np.int64)).tolist()
        counts, excluded = totals[:6], totals[6]
        denominator = sum(counts)
        peak = max(counts)
        tied = [index for index, count in enumerate(counts) if count == peak] if denominator else []
        fraction = peak / denominator if denominator else 0.0
        vote = {
            "class_counts": counts, "denominator": denominator,
            "winner": min(tied) if tied else -1, "tied_winners": tied,
            "is_tie": len(tied) > 1, "winning_fraction": fraction,
            "winning_fraction_4dp": round(fraction, 4), "excluded_255_weight": excluded,
        }
        require(denominator + excluded == sum(n * c for n, c in zip(histogram, coefficients)),
                "Integer conservation failure")
        if mode == "weighted":
            vote["effective_map_cells"] = denominator / 4
        votes[mode] = vote
    return votes, histogram, valid_pixels


def replay_row(row, grid, weights):
    label, fraction = row["accepted_label"], row["accepted_fraction"]
    require(type(label) is int and 0 <= label < 6, "Accepted label outside six classes")
    require(type(fraction) in (int, float) and math.isfinite(fraction)
            and 0 <= fraction <= 1, "Accepted fraction outside [0,1]")
    votes, histogram, valid = replay_grid(grid, weights)
    baseline = votes["baseline"]
    expected = {
        "votes": votes, "weight_histogram_0_to_4": histogram,
        "sar_valid_pixels": valid, "sar_zero_pixels": 16384 - valid,
        "baseline_reproduction": {
            "label_disagrees": baseline["winner"] != label,
            "fraction_disagrees": baseline["winning_fraction_4dp"] != fraction,
        },
        "sensitivity": {mode: {
            "winner_differs_from_baseline": votes[mode]["winner"] != baseline["winner"],
            "winner_differs_from_accepted": votes[mode]["winner"] != label,
        } for mode in ("weighted", "all_four", "any_valid")},
    }
    for key, value in expected.items():
        equal(row[key], value, row["tile_id"] + "." + key)
    return {**expected, "tile_id": row["tile_id"], "accepted_label": label}


def empty_group():
    return {
        "tiles": 0,
        "baseline_reproduction": {"label_disagrees": 0, "fraction_disagrees": 0},
        "modes": {mode: {
            "class_counts": [0] * 6, "denominator": 0, "tied_tiles": 0,
            "zero_support_tiles": 0, "winner_differs_from_baseline": 0,
            "winner_differs_from_accepted": 0,
        } for mode in COEFFICIENTS},
    }


def replay_summary(rows):
    """Accumulate independently replayed rows into two strata and six classes."""
    summary = {name: {"all": empty_group(), "by_accepted_class": {
        str(label): empty_group() for label in range(6)}}
        for name in ("all_partial", "inspection_full_only")}
    for row in rows:
        stratum = "all_partial" if row["sar_zero_pixels"] else "inspection_full_only"
        groups = summary[stratum]
        for accumulator in (groups["all"], groups["by_accepted_class"][str(row["accepted_label"])]):
            accumulator["tiles"] += 1
            for key, value in row["baseline_reproduction"].items():
                accumulator["baseline_reproduction"][key] += int(value)
            for mode, vote in row["votes"].items():
                result = accumulator["modes"][mode]
                for index, count in enumerate(vote["class_counts"]):
                    result["class_counts"][index] += count
                result["denominator"] += vote["denominator"]
                result["tied_tiles"] += int(len(vote["tied_winners"]) > 1)
                result["zero_support_tiles"] += int(vote["denominator"] == 0)
                result["winner_differs_from_baseline"] += int(vote["winner"] != row["votes"]["baseline"]["winner"])
                result["winner_differs_from_accepted"] += int(vote["winner"] != row["accepted_label"])
    return summary


def four_slice_weights(sar):
    require(sar.shape == (128, 128) and sar.dtype == np.dtype("float32"), "SAR shape/dtype")
    require(np.isfinite(sar).all() and (sar >= 0).all(), "Invalid SAR samples")
    mask = sar > 0
    weights = (mask[0::2, 0::2].astype(np.uint8) + mask[0::2, 1::2].astype(np.uint8)
               + mask[1::2, 0::2].astype(np.uint8) + mask[1::2, 1::2].astype(np.uint8))
    return mask, weights


def check_inspection(packet, grid, weights, tile_id):
    mask, expected_weights = four_slice_weights(packet["sar"])
    expected = {"sar_valid": mask, "weights": expected_weights, "map_grid": grid,
                "map_valid": grid != 255, "all_four": expected_weights == 4,
                "any_valid": expected_weights > 0}
    for key, value in expected.items():
        observed = packet[key]
        require(observed.dtype == value.dtype and observed.shape == value.shape
                and np.array_equal(observed, value), f"{tile_id}: inspection {key} differs")
    require(np.array_equal(weights, expected_weights), f"{tile_id}: replay packet weights differ from SAR")
    require(int(mask.sum()) == int(expected_weights.astype(np.int64).sum()), f"{tile_id}: SAR weight conservation")


def audit(args):
    root = args.run_dir.resolve()
    manifest_path = member_path(root, "run_manifest.json")
    manifest_hash = sha256(manifest_path)
    if args.expect_manifest_sha256:
        equal(manifest_hash, args.expect_manifest_sha256, "manifest digest")
    manifest = read_json(manifest_path)
    equal(manifest["status"], "complete", "run status")
    equal(manifest["schema_version"], 1, "manifest schema")
    equal(manifest["git"]["status"], "", "producer cleanliness record")
    if args.expect_producer:
        equal(manifest["git"]["commit"], args.expect_producer, "producer commit")
    require(bool(manifest.get("finished_utc")), "No finish time")
    identities = manifest["outputs"]
    require(isinstance(identities, dict), "Missing output hashes")
    for name, expected in identities.items():
        equal(sha256(member_path(root, name)), expected, f"output digest: {name}")
    selection = read_json(member_path(root, "selection.json"))
    results = read_json(member_path(root, "results.json"))
    bindings = read_json(member_path(root, "bindings.json"))
    equal(identities["bindings.json"], manifest["bindings_sha256"], "bindings digest")
    equal(bindings["producer_commit"], manifest["git"]["commit"], "bound producer")
    for key in ("sources", "inputs", "environment"):
        equal(bindings[key], manifest[key], "bound " + key)
    equal(results["schema_version"], 1, "results schema")
    equal(results["interpretation_limits"], manifest["interpretation_limits"], "interpretation limits")
    require(bool(results["interpretation_limits"]) and bool(results["vote_inputs_scope"]), "Missing scope limits")
    equal(results["vote_inputs"], "vote_inputs.npz", "vote packet filename")
    equal(results["archive_verified_tiles"], args.expected_archive_tiles, "recorded archive tiles")
    equal(results["archive_verified_members"], args.expected_archive_tiles + 2, "recorded archive members")
    equal(selection["selected_before_sampling"], True, "selection timing claim")
    sample_ids, partial_ids = selection["sample_ids"], selection["partial_ids"]
    inspection = selection["inspection"]
    inspection_ids = [item["tile_id"] for item in inspection]
    require(all(isinstance(value, str) and value for value in sample_ids), "Invalid sample IDs")
    require(len(set(inspection_ids)) == len(inspection_ids) == args.expected_inspections, "Inspection IDs/count")
    require(len(set(partial_ids)) == len(partial_ids) == args.expected_partial, "Partial IDs/count")
    equal(sample_ids, sorted(set(partial_ids) | set(inspection_ids)), "selected union")
    equal(selection["maximum_map_samples"], args.expected_partial + args.expected_inspections, "selection bound")
    require(len(sample_ids) <= selection["maximum_map_samples"], "Sample bound exceeded")
    equal(results["sampled_tiles"], len(sample_ids), "sampled count")
    equal(results["inspection_tiles"], len(inspection_ids), "inspection count")
    equal([row["tile_id"] for row in results["tiles"]], sample_ids, "result row order")
    inspection_names = {f"inspection/{tile_id}.npz" for tile_id in inspection_ids}
    expected_outputs = {"bindings.json", "decoder.stderr", "results.json", "selection.json", "vote_inputs.npz"} | inspection_names
    require(set(identities) == expected_outputs, "Manifest output inventory differs")
    actual_inspection_names = {p.relative_to(root).as_posix() for p in (root / "inspection").iterdir()}
    require(actual_inspection_names == inspection_names, "Inspection directory inventory differs")
    bundle = arrays(member_path(root, "vote_inputs.npz"), ("tile_ids", "map_grids", "weights"))
    require(bundle["tile_ids"].ndim == 1 and bundle["tile_ids"].dtype.kind == "U", "IDs must be Unicode vector")
    equal(bundle["tile_ids"].tolist(), sample_ids, "NPZ tile order")
    for key in ("map_grids", "weights"):
        require(bundle[key].shape == (len(sample_ids), 64, 64) and bundle[key].dtype == np.uint8,
                f"{key}: shape/dtype")
    replayed = [replay_row(row, bundle["map_grids"][index], bundle["weights"][index])
                for index, row in enumerate(results["tiles"])]
    equal(sorted(row["tile_id"] for row in replayed if row["sar_zero_pixels"]), sorted(partial_ids), "replayed partial membership")
    equal({row["tile_id"] for row in results["tiles"] if "inspection" in row}, set(inspection_ids), "inspection row membership")
    summary = replay_summary(replayed)
    equal(results["summary"], summary, "all summary fields")
    positions = {tile_id: index for index, tile_id in enumerate(sample_ids)}
    for item in inspection:
        tile_id = item["tile_id"]
        index = positions[tile_id]
        row = results["tiles"][index]
        for key, value in item.items():
            equal(row["inspection"][key], value, f"{tile_id}.inspection.{key}")
        equal(item["accepted_label"], row["accepted_label"], f"{tile_id}.class")
        equal(item["coverage_stratum"], "partial" if replayed[index]["sar_zero_pixels"] else "full", f"{tile_id}.coverage")
        name = f"inspection/{tile_id}.npz"
        equal(row["inspection"]["npz"], name, f"{tile_id}.packet path")
        packet = arrays(member_path(root, name), ("sar", "sar_valid", "map_grid", "map_valid", "weights", "all_four", "any_valid"))
        check_inspection(packet, bundle["map_grids"][index], bundle["weights"][index], tile_id)
    for name, expected in identities.items():
        equal(sha256(member_path(root, name)), expected, f"unchanged output: {name}")
    equal(sha256(manifest_path), manifest_hash, "unchanged manifest")
    return {
        "run_status": manifest["status"], "producer_commit": manifest["git"]["commit"],
        "run_manifest_sha256": manifest_hash, "output_sha256": identities,
        "sources_recorded_by_producer": manifest["sources"],
        "checked_tiles": len(sample_ids), "checked_vote_records": len(sample_ids) * 4,
        "checked_inspection_packets": len(inspection_ids), "checked_summary_groups": 14,
        "checked_summary_mode_records": 56, "input_bytes_unchanged_after_replay": True,
        "packet_raw_array_bytes": sum(value.nbytes for value in bundle.values()),
        "replayed_summary": summary, "producer_interpretation_limits": results["interpretation_limits"],
        "producer_vote_inputs_scope": results["vote_inputs_scope"],
        "inspected_tile_ids": inspection_ids,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--report", type=Path, required=True, help="New JSON receipt outside input bundle")
    parser.add_argument("--expect-producer")
    parser.add_argument("--expect-manifest-sha256")
    parser.add_argument("--expected-partial", type=int, default=2651)
    parser.add_argument("--expected-inspections", type=int, default=60)
    parser.add_argument("--expected-archive-tiles", type=int, default=23380)
    args = parser.parse_args(argv)
    require(not args.report.resolve().is_relative_to(args.run_dir.resolve()), "Receipt must be outside input bundle")
    started = time.monotonic()
    receipt = {"schema_version": 1, "status": "failed", "started_utc": datetime.now(timezone.utc).isoformat(),
               "checker_sha256": sha256(__file__), "python": platform.python_version(),
               "numpy": np.__version__, "scope_limits": LIMITS}
    with args.report.open("x") as output:
        try:
            receipt.update(audit(args))
            receipt["status"] = "passed"
            exit_code = 0
        except Exception as error:
            receipt.update(error_type=type(error).__name__, error=str(error))
            exit_code = 1
        receipt["finished_utc"] = datetime.now(timezone.utc).isoformat()
        receipt["elapsed_seconds"] = time.monotonic() - started
        output.write(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: receipt[key] for key in ("status", "elapsed_seconds", "error") if key in receipt}))
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
