This calculation uses the unchanged scientific-supplement.zip supplied separately with the manuscript. It reconstructs class counts, confusion matrices and coverage subsets from the accepted predictions. It performs no model inference or fitting. Python and NumPy are required.

From this directory, use a new output path:

```sh
python analyze_sar_coverage.py --package /path/to/scientific-supplement.zip --sha256 67b6aa65be5bab9b7cbe83df90aafcf7b479117291562471652f59ed7f182a1d --output /new/path/replayed-coverage.json
```

Compare every field except execution, which records the current command and runtime:

```python
import json
from pathlib import Path
original = json.loads(Path("results.json").read_text())
replayed = json.loads(Path("/new/path/replayed-coverage.json").read_text())
original.pop("execution")
replayed.pop("execution")
assert original == replayed
```

The distributed results omit only the original execution.argv, which contained private local paths. Their scientific values are unchanged. The original result SHA256 is 3170d9e92e88e32812b848df7448df8f04af0aa3cb717acb3978680af3fb8de3. The package manifest identifies the redistributed bytes separately. Source and accepted input digests remain in execution.

Each regional macro F1 requires all six truth classes under this analysis's reporting rule. Undefined class ratios are null; false positives still enter precision and F1. Seed means precede regional means. Withholding a partial-coverage macro mean is a reporting choice for comparable six-class coverage, not a claim that other macro definitions are mathematically impossible. Class and geographic composition differ between subsets, so score differences do not isolate a missing-pixel effect.

Partial-training predictions use the original package's accepted catalog test ordering. They do not carry independent image IDs in each vector; this calculation inherits that verified export convention. The calculation does not independently recover those IDs from original training outputs.
