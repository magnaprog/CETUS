"""Format the reviewed coverage calculation as two supplementary tables."""

import argparse
import hashlib
import json
from pathlib import Path


def render(result):
    rows = result['results']
    counts = []
    for fold in range(5):
        records = [r for r in rows if r['fold'] == fold]
        first = records[0]['scores']
        for record in records:
            for group in ('all', 'complete', 'partial'):
                if record['scores'][group]['support'] != first[group]['support']:
                    raise ValueError('Class counts differ across methods')
        counts.append(str(fold + 1) + ' & ' + ' & '.join(
            f"{whole}/{partial}" for whole, partial in zip(
                first['complete']['support'], first['partial']['support'])) + r' \\')
    counts = '\n'.join([
        r'\begin{tabular}{@{}lrrrrrr@{}}', r'\toprule',
        r'Region & Plains & Dunes & Hummocky & Labyrinths & Lakes & Craters \\',
        r'\midrule', *counts, r'\bottomrule', r'\end{tabular}', ''])
    summaries = {(r['family'], r['model'], r['group']): r for r in result['summaries']}
    names = [('linear', 'combined_classical', 'Combined classical LR'),
             ('linear', 'random_init', 'Untrained ViT LR'),
             ('linear', 'dinov2', 'DINOv2 LR'), ('linear', 'dofa', 'DOFA LR'),
             ('linear', 'croma', 'CROMA LR'),
             ('partial_training', 'dinov2', 'DINOv2 training'),
             ('partial_training', 'dofa', 'DOFA training'),
             ('partial_training', 'croma', 'CROMA training')]
    values = []
    for family, model, label in names:
        cells = []
        for group in ('all', 'complete'):
            row = summaries[family, model, group]
            cells.append(f"${100 * row['mean_macro_f1']:.2f} \\pm {100 * row['sample_sd']:.2f}$")
        values.append(label + ' & ' + ' & '.join(cells) + r' \\')
    scores = '\n'.join([
        r'\begin{tabular}{@{}lrr@{}}', r'\toprule',
        r'Method & All images & Complete SAR \\', r'\midrule',
        *values, r'\bottomrule', r'\end{tabular}', ''])
    return {'coverage-counts.tex': counts, 'coverage-scores.tex': scores}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    raw = args.result.read_bytes()
    if hashlib.sha256(raw).hexdigest() != args.sha256:
        raise ValueError('Result digest differs')
    tables = render(json.loads(raw))
    args.output.mkdir(parents=True, exist_ok=False)
    for name, text in tables.items():
        (args.output / name).write_text(text)


if __name__ == '__main__':
    main()
