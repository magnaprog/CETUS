The sixty SAR inspection arrays derive from the Cassini SAR HiSAR Global Mosaic 351 m, through flyby T104. Credit the Cassini SAR Team, NASA Jet Propulsion Laboratory and USGS Astrogeology Science Center. The arrays are bilinear samples from this display-DN mosaic; they are not calibrated backscatter measurements.
https://astrogeology.usgs.gov/search/map/titan_cassini_sar_hisar_global_mosaic_351m

Map grids derive from Ashley Schoenfeld, Titan Global Map Shapefiles, version 1, Mendeley Data, DOI 10.17632/f6jrtyfp66.1, and the map of Lopes et al. (2020), A global geomorphologic map of Saturn's moon Titan, Nature Astronomy 4, 228–233. The Mendeley record licenses the source under CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Changes comprise rasterization, projection and nearest-neighbor local sampling, then integer coverage-weighted counts. These derived data retain the original accepted tile labels; they do not claim independent geological interpretation.
https://data.mendeley.com/datasets/f6jrtyfp66/1

Neither source attribution nor an anonymous review package implies source endorsement or a publicly hosted complete benchmark release. No VIMS/ISS, Earth or Venus images are included in this companion.
