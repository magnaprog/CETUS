# Saved model-follow-up numeric companion

This is a derived anonymous numeric record. It reconstructs saved predictions,
compact training histories and validation choices on CPU. It does not train or
run a model, regenerate probabilities, load states/features, reconstruct omitted
per-epoch prediction vectors, or repeat complete private bundle admission.

From this extracted directory with Python3.12 and NumPy2.4.4:

    CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
      python3 -B reconstruct.py --output /absolute/new/path/reconstruction.json

The output must be new and outside this package. No installation, downloads,
Torch, sklearn, GPU, images or model weights are needed. Optional plotting is
not part of this companion. `manifest.json` and `SHA256SUMS` enumerate all files
exactly; verification rejects missing, altered, extra and symlink payloads.

The checker covers 90 cells:30 fixed-C=1 DINO readouts,30 full-budget CNN tuning
fits and30 final CNN fits. The60 native test records include exact saved IDs,
labels, predictions, logits, probabilities and dtype declarations. Predictions
are checked against logits' argmax, not rounded probabilities. The6000 compact
history rows preserve validation confusion matrices, unrounded scores, losses,
loss numerators/denominators, learning rates, example/update counts and finite
flags. The checker recomputes confusion metrics, loss ratios and cosine rates,
checks the100-epoch budgets, verifies earliest maximum unrounded validation F1,
and verifies all10 choices across three complete LR candidates, ties to lower LR.
It does not prove that recorded optimizer steps occurred or reproduce their
numerators from omitted per-example logits.

Seed means precede five equal-weight regions and descriptive sample SD; seeds
are not independent regions. Two initialization contrasts retain every paired
region. Coverage uses unchanged all/complete/partial membership by explicit tile
ID. The180 cohort confusion matrices and summaries retain unsupported-class nulls;
regions are never omitted to make a six-class macro summary available. The two
model families have different fitting procedures. These are exploratory map-label
agreement measurements, not independent geological truth or convergence proof.

The catalog and five splits preserve the earlier anonymous package bytes.
Execution used a different original catalog identity. Their ID/label and role
correspondence was checked during projection; this is not a new run on public
catalog bytes. Three original external failures remain described in the payload:
two intentionally stopped CNN attempts and one completed DINO computation rejected
by an external native-library audit. There were no genuine runner failed.json
receipts. Missing raw maps for the rejected DINO attempt remain unavailable.

`data/records.json.gz` contains the native records, compact histories, selection
metadata and numeric comparison targets. `source_epoch_sha256` references omitted
private epoch records; it is not a packaged-file claim. Warning/iteration and
source-state identity fields are retained; they are not fitted-optimum claims.
Private field mappings, machine paths, supervision logs and original full results
are not public payloads. Copied arithmetic helper sources are unchanged; their
private/historical CLIs require inputs not included here. Use only reconstruct.py.

Author-owned code uses the existing anonymous review MIT notice in LICENSE.
Third-party attribution is preserved in DATA_LICENSES.md, THIRD_PARTY_NOTICES.md
and licenses/CROMA-LICENSE. The original two supplement archives are unchanged.
