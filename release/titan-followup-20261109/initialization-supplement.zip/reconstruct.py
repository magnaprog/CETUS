"""Reconstruct the finite saved-result companion on CPU. No model or fitting code."""
import argparse
import gzip
import hashlib
import json
import math
from pathlib import Path

import numpy as np
from scripts import analyze_model_followup as primary
from scripts import analyze_model_followup_coverage as coverage

SCHEMA = 'model-followup-numeric-v1'
require = primary.require
NATIVE = 'tile_ids labels predictions logits probabilities logits_dtype probabilities_dtype class_order probability_argmax_disagreements confusion_matrix support_per_class true_positive false_positive false_negative precision_per_class recall_per_class f1_per_class macro_f1 balanced_accuracy kappa'.split()
LOSS = 'loss loss_numerator loss_denominator'.split()
HISTORY = 'epoch examples finite_gradients loss_denominator loss_numerator lr optimizer_steps train_loss val_confusion_matrix val_loss val_loss_denominator val_loss_numerator val_macro_f1'.split()
METRICS = 'confusion_matrix support_per_class true_positive false_positive false_negative precision_per_class recall_per_class f1_per_class macro_f1 balanced_accuracy kappa n ordered_ids_sha256 labels_sha256'.split()
CLASSIFIER = 'C class_weight dual fit_intercept intercept_scaling l1_ratio max_iter n_jobs penalty random_state solver tol verbose warm_start'.split()
SCALER = 'copy with_mean with_std'.split()
COMMON = 'cell result_sha256 identity inputs_sha256 validation'.split()
DINO = 'feature_result_sha256 classifier_parameters scaler_parameters n_iter warnings feature_dtype coefficient_dtype readout convergence_claim test test_summary'.split()
CNN = 'recipe seed head_seed loader_seed selected_epoch selected_score selected_state_sha256 final_state_sha256 training_class_weights validation_history tuning_results selection'.split()
EXPECTED = primary._expected_grid()
TEST_CELLS = {c for c in EXPECTED if c[0] != 'tuning'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    data = Path(path).read_bytes()
    if str(path).endswith('.gz'):
        data = gzip.decompress(data)
    return json.loads(data, object_pairs_hook=primary._object,
                      parse_float=primary._number, parse_constant=primary._number)


def equal(actual, expected, label, atol=1e-15):
    """Exact shape/keys/integers/nulls; reviewed follow-up absolute float bound."""
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and set(actual) == set(expected), label + ': keys differ')
        for key in expected:
            equal(actual[key], expected[key], label + '/' + key, atol)
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(actual) == len(expected), label + ': length differs')
        for i, (a, e) in enumerate(zip(actual, expected)):
            equal(a, e, label + '/' + str(i), atol)
    elif type(expected) is float:
        require(type(actual) in (int, float) and math.isfinite(actual)
                and abs(actual - expected) <= atol, label + ': float differs')
    else:
        require(type(actual) is type(expected) and actual == expected, label + ': exact value differs')


def keyed(rows, expected):
    result = {}
    for row in rows:
        c = row['cell']
        require(isinstance(c, list) and len(c) == 4 and type(c[1]) is int
                and type(c[3]) is (float if c[0] == 'tuning' else int), 'Invalid cell identity')
        c = tuple(c)
        require(c not in result and c in expected, 'Duplicate/unexpected cell')
        result[c] = row
    require(set(result) == expected, 'Missing cells')
    return result


def truths(catalog, splits, populations, purpose):
    require(catalog['class_names'] == primary.CLASSES, 'Catalog class order')
    tiles = catalog['tiles']; ids = [t['tile_id'] for t in tiles]
    require(len(ids) == len(set(ids)) and all(isinstance(i, str) and i for i in ids), 'Catalog duplicate/invalid IDs')
    require(all(type(t['label']) is int and 0 <= t['label'] < 6
                and type(t['valid_fraction']) in (int, float) and math.isfinite(t['valid_fraction'])
                and 0 <= t['valid_fraction'] <= 1 for t in tiles), 'Invalid catalog values')
    require(len(splits) == len(populations) == 5, 'Five folds required')
    truth, counts, seen = [], [], set()
    for f, (split, pop) in enumerate(zip(splits, populations)):
        require(split['policy']['test_fold'] == f and type(split['policy']['test_fold']) is int
                and set(split['assignments']) == set(ids)
                and set(split['assignments'].values()) <= set(primary.ROLES) | {'buffer_excluded', 'selk_holdout'}, 'Split assignments differ')
        require(pop['fold'] == f and set(pop) == {'fold', 'tile_ids', 'counts'}, 'Population fold/fields differ')
        by_role, by_count = {}, {}
        for role in primary.ROLES:
            rows = [t for t in tiles if split['assignments'][t['tile_id']] == role]
            by_role[role] = {'tile_ids': [t['tile_id'] for t in rows], 'labels': [t['label'] for t in rows]}
            support = np.bincount(by_role[role]['labels'], minlength=6).tolist()
            require(all(support), 'Every role must have six truth classes')
            by_count[role] = {'total': len(rows), 'class_counts': support}
        test = by_role['test']['tile_ids']
        require(not seen.intersection(test), 'Repeated test ID across folds'); seen.update(test)
        test_set = set(test)
        expected = {'all': test, 'complete': [t['tile_id'] for t in tiles if t['tile_id'] in test_set and t['valid_fraction'] == 1],
                    'partial': [t['tile_id'] for t in tiles if t['tile_id'] in test_set and t['valid_fraction'] < 1]}
        equal(pop['tile_ids'], expected, 'Fixed coverage membership')
        labels = {t['tile_id']: t['label'] for t in tiles}
        pc = {g: {'n': len(v), 'class_counts': [sum(labels[i] == c for i in v) for c in range(6)]} for g, v in expected.items()}
        equal(pop['counts'], pc, 'Cohort supports')
        require(all(pc['complete']['class_counts']), 'Complete cohort lacks a class')
        truth.append(by_role); counts.append(by_count)
    if purpose == 'titan_followup':
        require(len(tiles) == 23380 and len(seen) == 23246, 'Wrong Titan catalog/test counts')
        require([sum(p['counts'][g]['n'] for p in populations) for g in coverage.coverage.GROUPS] == [23246, 20603, 2643], 'Wrong fixed cohort sizes')
    return truth, counts


def confusion_metrics(matrix, truth):
    """Same six-class formulas as primary.prediction_metrics, from integer CM only."""
    cm = np.asarray(matrix)
    require(cm.shape == (6, 6) and cm.dtype.kind in 'iu' and (cm >= 0).all(), 'Invalid history confusion')
    support, called, tp = cm.sum(1), cm.sum(0), cm.diagonal()
    require(np.array_equal(support, np.bincount(truth['labels'], minlength=6)) and (support > 0).all(), 'History truth support differs')
    precision = np.divide(tp, called, out=np.zeros(6), where=called != 0)
    recall = tp / support; f1 = 2 * tp / (support + called)
    n = int(support.sum()); observed = float(tp.sum()) / n; expected = float(support @ called) / n**2
    return {'confusion_matrix': cm.tolist(), 'support_per_class': support.tolist(), 'true_positive': tp.tolist(),
            'false_positive': (called - tp).tolist(), 'false_negative': (support - tp).tolist(),
            'precision_per_class': precision.tolist(), 'recall_per_class': recall.tolist(), 'f1_per_class': f1.tolist(),
            'macro_f1': float(f1.mean()), 'balanced_accuracy': float(recall.mean()), 'kappa': (observed - expected)/(1-expected),
            'n': n, 'ordered_ids_sha256': primary.digest(truth['tile_ids']), 'labels_sha256': primary.digest(truth['labels'])}


def history_check(row, truth, counts):
    recipe = row['recipe']
    equal({k: v for k, v in recipe.items() if k != 'lr'}, primary.RECIPE, 'CNN recipe')
    require(recipe['lr'] in primary.LRS, 'Invalid LR')
    if row['cell'][0] == 'tuning':
        require(recipe['lr'] == row['cell'][3], 'Tuning recipe LR differs from cell identity')
    seed = 100 if row['cell'][0] == 'tuning' else row['cell'][3]
    require(row['seed'] == seed and row['head_seed'] == 20000 + seed and row['loader_seed'] == 10000 + seed, 'Independent seed contract')
    require(len(row['validation_history']) == 100, 'Exactly 100 compact epochs required')
    best, epoch, selected = -1., None, None
    for e, entry in enumerate(row['validation_history'], 1):
        require(set(entry) == {'history', 'metrics', 'source_epoch_sha256'}, 'History entry fields')
        h = entry['history']; require(set(h) == set(HISTORY), 'History fields differ')
        require(type(h['epoch']) is int and h['epoch'] == e and h['finite_gradients'] is True, 'Epoch order/finite flag')
        require(type(h['examples']) is int and h['examples'] == counts['train']['total']
                and type(h['optimizer_steps']) is int and h['optimizer_steps'] == math.ceil(h['examples']/32), 'Training budget differs')
        m = confusion_metrics(h['val_confusion_matrix'], truth['val'])
        equal(entry['metrics'], m, 'Compact validation metrics')
        primary._close(h['val_macro_f1'], m['macro_f1'], 'History validation F1')
        for prefix, numerator, denominator in [('train', 'loss_numerator', 'loss_denominator'), ('val', 'val_loss_numerator', 'val_loss_denominator')]:
            require(h[numerator] >= 0 and h[denominator] > 0, 'Invalid loss ratio')
            primary._close(h[prefix+'_loss'], h[numerator]/h[denominator], 'Compact loss ratio', 1e-12)
        primary._close(h['lr'], recipe['lr']*(1+math.cos(math.pi*(e-1)/100))/2, 'Cosine rate', 1e-14)
        primary._sha(entry['source_epoch_sha256'])
        if h['val_macro_f1'] > best:
            best, epoch, selected = h['val_macro_f1'], e, m
    require(row['selected_epoch'] == epoch and type(row['selected_epoch']) is int and row['selected_score'] == best, 'Earliest unrounded epoch selection differs')
    equal(row['validation'], selected, 'Selected validation summary')
    return best


def reconstruct(data, catalog, splits):
    require(data['schema_version'] == SCHEMA and data['purpose'] in ('titan_followup', 'synthetic_cpu_test')
            and data['class_order'] == primary.CLASSES, 'Wrong numeric schema/purpose/classes')
    require(set(data) == {'schema_version','purpose','class_order','sources','fold_counts','populations','cells','targets','exclusions'}, 'Unknown public payload fields')
    truth, counts = truths(catalog, splits, data['populations'], data['purpose'])
    equal(data['fold_counts'], counts, 'Role counts')
    cells = keyed(data['cells'], EXPECTED)
    cov_targets = keyed(data['targets']['coverage_results'], TEST_CELLS)
    metrics, cohort_cells = {}, {}
    for c, row in sorted(cells.items()):
        fields = set(COMMON + (DINO if c[0] == 'dino_c1' else CNN))
        if c[0] == 'final': fields |= {'test', 'test_summary'}
        require(set(row) == fields, 'Unexpected cell fields/test role')
        primary._sha(row['result_sha256']); primary._sha(row['inputs_sha256'])
        identity = row['identity']; require(identity['initialization'] == c[2], 'Initialization identity differs')
        if c[0] == 'dino_c1':
            require(identity['encoder_seed'] == c[3], 'Encoder seed differs')
            p = row['classifier_parameters']; require(set(p) == set(CLASSIFIER), 'Classifier fields')
            require(all(p[k] == v for k,v in {'C':1.,'solver':'lbfgs','max_iter':2000,'tol':1e-4,'class_weight':'balanced','random_state':0,'fit_intercept':True}.items())
                    and p['penalty'] in ('l2','deprecated') and p['l1_ratio'] in (None,0,0.), 'C1 recipe')
            require(row['scaler_parameters'] == {'copy':True,'with_mean':True,'with_std':True}
                    and row['convergence_claim'] is False and row['feature_dtype'] == 'float32'
                    and row['coefficient_dtype'] in ('float32','float64'), 'C1 state metadata')
            require(isinstance(row['warnings'],list) and len(row['n_iter']) == 1 and type(row['n_iter'][0]) is int and 0 < row['n_iter'][0] <= 2000, 'C1 iteration/warning record')
        else:
            require(identity['backbone_seed'] == row['seed'] and identity['head_seed'] == row['head_seed'], 'CNN state seed metadata')
            history_check(row, truth[c[1]], counts[c[1]])
            if c[0] == 'tuning': require(row['selection'] is None and row['tuning_results'] == [], 'Tuning must not have LR selection')
        if c[0] != 'tuning':
            require(set(row['test']) == set(NATIVE + (LOSS if c[0] == 'final' else [])), 'Native prediction fields')
            m, scores = coverage.joined_scores(row['test'], truth[c[1]]['test'], data['populations'][c[1]]['tile_ids'])
            equal(m, row['test_summary'], 'Native test summary')
            metrics[c] = {'cell': list(c), 'test': m}
            cohort_cells[c] = {'cell':list(c), 'scores':scores}
            equal(cov_targets[c], {'cell':list(c),'scores':scores,'ordered_ids_sha256':m['ordered_ids_sha256'],'labels_sha256':m['labels_sha256']}, 'Coverage target')
    choices = []
    for f in range(5):
        for arm in ('scratch','pretrained'):
            candidates = [cells['tuning',f,arm,lr] for lr in primary.LRS]
            winner = max(candidates, key=lambda r:(r['selected_score'],-r['recipe']['lr']))
            expected = {r['result_sha256']:r for r in candidates}
            require(len(expected) == 3, 'Duplicate tuning result SHA')
            for seed in range(3):
                r = cells['final',f,arm,seed]; refs=r['tuning_results']
                require(len(refs)==3 and set(refs)==set(expected), 'Final must bind all three tuning candidates')
                require(r['recipe']['lr'] == winner['recipe']['lr'], 'Wrong lower-LR tie selection')
                selection={'lr':winner['recipe']['lr'],'candidates':[{'lr':expected[h]['recipe']['lr'],'score':expected[h]['selected_score'],'result_sha256':h} for h in refs],
                           'rule':'maximum validation macro_f1, then lower LR'}
                equal(r['selection'],selection,'Saved LR choice',atol=0)
            choices.append({'fold':f,'initialization':arm,'lr':winner['recipe']['lr']})
    summary=primary.aggregate(metrics); equal(data['targets']['summary'],summary,'Seed/region aggregation')
    cohorts=coverage.summarize(cohort_cells); equal(data['targets']['coverage_cohorts'],cohorts,'Coverage aggregation/nulls')
    return {'schema_version':SCHEMA,'status':'numeric_reconstruction_pass','purpose':data['purpose'],
            'checks':{'native_test_vectors':60,'compact_history_rows':6000,'cells':90,'lr_choices':10,'cohort_confusions':180},
            'lr_choices':choices,'summary':summary,'coverage_cohorts':cohorts,
            'scope':{'epoch_prediction_vectors_reconstructed':False,'probability_generation':False,'state_replay':False,
                     'training_or_inference':False,'full_primary_bundle_admission':False,'convergence_claim':False},
            'numeric_bounds':{'derived_metrics_atol':1e-15,'rtol':0,'loss_ratios_atol':1e-12,'cosine_atol':1e-14,
                              'probability_sums_atol':'inherited native float32 1e-6 / float64 1e-12; no changes'}}


def verify_manifest(root):
    manifest=read(root/'manifest.json')
    require(manifest['schema_version']==SCHEMA, 'Manifest schema')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    require(not any(p.is_symlink() for p in root.rglob('*')), 'Symlink payload')
    require(actual == set(manifest['files']) | {'manifest.json','SHA256SUMS'}, 'Missing/extra package files')
    for name,v in manifest['files'].items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and sha(root/name)==v['sha256'] and (root/name).stat().st_size==v['bytes'], 'Payload SHA/size differs')
    expected={n:sha(root/n) for n in actual if n!='SHA256SUMS'}; got={}
    for line in (root/'SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1); require(n not in got,'Duplicate checksum entry');got[n]=h
    require(got==expected,'Checksum index differs')
    return manifest


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args(argv)
    root=Path(__file__).resolve().parent
    require(not a.output.resolve().is_relative_to(root) and not a.output.exists(),'Output must be new and outside package')
    manifest=verify_manifest(root);data=read(root/'data/records.json.gz');catalog=read(root/'data/catalog.json')
    splits=[read(root/f'data/splits/titan_contiguous_fold_{f}.json') for f in range(5)]
    require(all(s['catalog_sha256']==sha(root/'data/catalog.json') for s in splits),'Packaged split/catalog hash')
    result=reconstruct(data,catalog,splits); result['manifest_sha256']=sha(root/'manifest.json')
    verify_manifest(root)
    with a.output.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'status':result['status'],'output':str(a.output),'sha256':sha(a.output),'checks':result['checks']}))
    return 0


if __name__=='__main__':
    raise SystemExit(main())
