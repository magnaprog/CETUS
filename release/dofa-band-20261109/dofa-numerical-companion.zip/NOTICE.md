The author-owned review copy temporarily withholds the author's copyright name
for anonymous assessment. The public license is unchanged. LICENSE is copied
verbatim from the existing anonymous numerical release. Third-party authors,
credits and rights have not been anonymized or removed.

DATA_LICENSES.md and THIRD_PARTY_NOTICES.md are retained verbatim from that
release. Their references to the wider catalog, imagery and other missions
describe the broader release; this companion contains only Titan test IDs,
map-derived labels, predictions, probabilities and numerical result metadata.
It contains no imagery, VIMS/ISS samples, Sentinel/DEM products, third-party
model source or weights. Retained broader notices do not imply those payloads
are included here. In particular, retain the Cassini SAR Team, Jet Propulsion
Laboratory and USGS Astrogeology Science Center credit, and the CC BY 4.0
attribution to the Titan Global Map Shapefiles, contributor Ashley Schoenfeld,
Mendeley Data version 1 (10.17632/f6jrtyfp66.1), and Lopes et al. 2020.

The ten fit records are projected to the numerical fields listed in README.md;
source values and JSON types are unchanged. Execution routing is omitted.
Expected cell metrics and the descriptive readout are copied from the completed
independent numerical report. This new NumPy checker reconstructs arithmetic
from saved vectors; it is not the native estimator checker. Code and
documentation for this companion were prepared with AI assistance and require
the author's review. No publication, independent human review or new scientific
execution is implied.
