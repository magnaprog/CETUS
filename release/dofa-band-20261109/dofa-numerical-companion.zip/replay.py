"""Reconstruct saved numerical results using NumPy and the Python standard library."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

EXPECTED_SHA256 = "63fb62510f5f8e8a7a6cdcf8b81288ba02003b85c8e8d86ff744fc9dcfc560e4"
BANDS = (13.78, 3.75)
METRICS = ("precision", "recall", "f1")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, ensure_ascii=True, allow_nan=False, sort_keys=True,
                       separators=(",", ":")) + "\n").encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def load(path):
    def invalid_constant(value):
        raise ValueError("Nonfinite JSON value")
    return json.loads(path.read_bytes(), object_pairs_hook=unique_object,
                      parse_constant=invalid_constant)


def verify_package(root):
    expected_bytes = (root / "expected.json").read_bytes()
    require(digest(expected_bytes) == EXPECTED_SHA256, "Frozen expected results changed")
    manifest = load(root / "manifest.json")
    require(manifest["schema"] == "dofa-companion-members-v1", "Manifest schema differs")
    actual_names = sorted(p.relative_to(root).as_posix() for p in root.rglob("*")
                          if p.is_file() and p != root / "manifest.json")
    require([r["member"] for r in manifest["files"]] == actual_names,
            "Missing, duplicate, reordered or extra package member")
    for record in manifest["files"]:
        path = root / record["member"]
        require(not path.is_symlink() and path.resolve().is_relative_to(root.resolve()),
                "Invalid package member")
        data = path.read_bytes()
        require(len(data) == record["bytes"] and digest(data) == record["sha256"],
                "Member bytes differ: " + record["member"])
    return load(root / "expected.json"), digest((root / "manifest.json").read_bytes())


def compare(actual, expected, label):
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and actual.keys() == expected.keys(), label + " keys differ")
        for key in expected:
            compare(actual[key], expected[key], label + "." + key)
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(actual) == len(expected), label + " length differs")
        for i, (a, e) in enumerate(zip(actual, expected)):
            compare(a, e, label + f"[{i}]")
    elif type(expected) in (int, float):
        require(type(actual) in (int, float) and np.isfinite(actual) and np.isfinite(expected),
                label + " is not finite numeric data")
        require(abs(actual - expected) <= (0 if type(actual) is type(expected) is int else 1e-12),
                label + " differs")
    else:
        require(type(actual) is type(expected) and actual == expected, label + " differs")


def confusion_metrics(counts):
    require(counts.shape == (6, 6) and counts.dtype.kind in "iu" and
            np.all(counts >= 0) and counts.sum() > 0, "Invalid confusion counts")
    truth = counts.sum(axis=1)
    predicted = counts.sum(axis=0)
    tp = np.diag(counts)
    per_class = {}
    for name, numerator, denominator in zip(METRICS, (tp, tp, 2 * tp),
                                            (predicted, truth, truth + predicted)):
        per_class[name] = np.divide(numerator, denominator, out=np.zeros(6, dtype=np.float64),
                                    where=denominator != 0).tolist()
    n = int(counts.sum())
    chance = sum(int(a) * int(b) for a, b in zip(truth, predicted)) / (n * n)
    require(chance < 1, "Undefined kappa")
    return {"confusion_counts": counts.tolist(), "support": truth.tolist(),
            "prediction_counts": predicted.tolist(), "true_positives": tp.tolist(),
            "per_class": per_class, "macro": {k: float(np.mean(v)) for k, v in per_class.items()},
            "kappa": (int(tp.sum()) / n - chance) / (1 - chance)}


def fold_statistics(values):
    first = values[0]
    if isinstance(first, dict):
        return {k: fold_statistics([v[k] for v in values]) for k in first}
    if isinstance(first, list):
        return [fold_statistics([v[i] for v in values]) for i in range(len(first))]
    array = np.asarray(values, dtype=np.float64)
    return {"mean": float(array.mean()), "sample_sd": float(array.std(ddof=1))}


def subtract(a, b):
    if isinstance(a, dict):
        return {k: subtract(a[k], b[k]) for k in a}
    if isinstance(a, list):
        return [subtract(x, y) for x, y in zip(a, b)]
    return a - b


def validate_cells(cells, expected):
    require(len(cells) == len(expected["cells"]) == 10, "All ten cells required")
    results = []
    for i, (cell, fixed) in enumerate(zip(cells, expected["cells"])):
        require(set(cell) == {"cell", "fold", "numeric_band_input", "tile_ids", "true_labels",
                "predictions", "probabilities", "probability_class_indices", "prediction_rule"},
                "Cell fields differ")
        require(type(cell["cell"]) is int and type(cell["fold"]) is int and
                (cell["cell"], cell["fold"]) == (i, i // 2) and
                cell["numeric_band_input"] == [BANDS[i % 2]] and
                type(cell["numeric_band_input"][0]) is float, "Cell order or identity differs")
        ids = cell["tile_ids"]
        require(isinstance(ids, list) and len(ids) == fixed["rows"] and
                all(type(s) is str for s in ids) and len(set(ids)) == len(ids), "Invalid or duplicate IDs")
        require(digest(encoded(ids)) == fixed["ordered_ids_sha256"], "Ordered IDs differ")
        require(cell["probability_class_indices"] == list(range(6)) and
                all(type(v) is int for v in cell["probability_class_indices"]) and
                cell["prediction_rule"] == "argmax", "Probability class order or rule differs")
        for name in ("true_labels", "predictions"):
            values = cell[name]
            require(isinstance(values, list) and len(values) == len(ids) and
                    all(type(v) is int and 0 <= v < 6 for v in values), "Invalid " + name)
        require(digest(encoded(cell["true_labels"])) == fixed["ordered_labels_sha256"],
                "Ordered true labels differ")
        raw = cell["probabilities"]
        require(isinstance(raw, list) and len(raw) == len(ids) and
                all(isinstance(row, list) and len(row) == 6 and all(type(x) is float for x in row)
                    for row in raw), "Invalid probability shape or JSON types")
        prob = np.asarray(raw, dtype=np.float64)
        require(np.isfinite(prob).all() and ((prob >= 0) & (prob <= 1)).all(), "Invalid probabilities")
        require(np.allclose(prob.sum(axis=1), 1, rtol=0, atol=1e-6), "Probability sums differ")
        pred = np.asarray(cell["predictions"], dtype=np.int64)
        truth = np.asarray(cell["true_labels"], dtype=np.int64)
        require(np.array_equal(prob[np.arange(len(ids)), pred], prob.max(axis=1)),
                "Prediction is not a probability maximum")
        if i % 2:
            require(ids == cells[i - 1]["tile_ids"] and cell["true_labels"] == cells[i - 1]["true_labels"],
                    "Paired membership differs")
        counts = np.bincount(6 * truth + pred, minlength=36).reshape(6, 6)
        metrics = confusion_metrics(counts)
        compare(metrics, fixed["metrics"], f"cell{i}.metrics")
        results.append({"cell": i, "fold": i // 2, "region": i // 2 + 1,
                        "band": BANDS[i % 2], "rows": len(ids), "metrics": metrics})
    return results


def aggregate(cells, expected):
    statistics = {str(b): fold_statistics([c["metrics"] for c in cells[arm::2]])
                  for arm, b in enumerate(BANDS)}
    compare(statistics, expected["fold_statistics"], "fold_statistics")
    differences = [subtract(cells[2 * f + 1]["metrics"], cells[2 * f]["metrics"]) for f in range(5)]
    scores = {str(b): [c["metrics"]["macro"]["f1"] for c in cells[arm::2]]
              for arm, b in enumerate(BANDS)}
    delta = 100 * (np.asarray(scores["3.75"]) - np.asarray(scores["13.78"]))
    pooled = {str(b): confusion_metrics(np.sum([c["metrics"]["confusion_counts"]
                                               for c in cells[arm::2]], axis=0, dtype=np.int64))
              for arm, b in enumerate(BANDS)}
    readout = {"macro_f1_by_fold": scores, "paired_difference_percentage_points": delta.tolist(),
        "equal_fold_mean_difference_percentage_points": float(delta.mean()),
        "sample_sd_difference_percentage_points": float(delta.std(ddof=1)),
        "secondary_pooled_counts_and_metrics": pooled,
        "historical_optimizer_equality_required": False,
        "limits": expected["descriptive_readout"]["limits"]}
    compare(readout, expected["descriptive_readout"], "descriptive_readout")
    return {"fold_statistics": statistics, "paired_3.75_minus_13.78": {
        "by_region": differences, "statistics": fold_statistics(differences)}, "descriptive_readout": readout}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="New JSON file outside the package")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    require(not args.output.resolve().is_relative_to(root), "Report must be external to package")
    expected, manifest_sha = verify_package(root)
    inputs = [load(root / f"cells/cell-{i:02d}.json") for i in range(10)]
    cells = validate_cells(inputs, expected)
    report = {"schema": "dofa-saved-arithmetic-replay-v1", "status": "passed",
        "scope": "saved numerical arithmetic only", "cells": cells,
        "expected_sha256": EXPECTED_SHA256, "manifest_sha256": manifest_sha,
        "numpy_version": np.__version__, "python_version": sys.version.split()[0],
        "probabilities_regenerated": False, "inference_or_fitting_performed": False,
        **aggregate(cells, expected)}
    with args.output.open("xb") as out:
        out.write(encoded(report))
    print("PASS: all 10 cells, 46492 saved rows; per-class, macro, kappa, fold and paired arithmetic")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError) as error:
        print("FAIL: " + str(error), file=sys.stderr)
        sys.exit(1)
