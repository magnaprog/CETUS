"""Build a deterministic ZIP and its complete external member manifest (stdlib only)."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if args.output.resolve().is_relative_to(root):
        parser.error("ZIP must be outside package")
    members_path = args.output.with_suffix(".members.json")
    if args.output.exists() or members_path.exists():
        parser.error("Output ZIP and member manifest must both be new")
    manifest = json.loads((root / "manifest.json").read_bytes())
    paths = sorted(p for p in root.rglob("*") if p.is_file())
    names = [p.relative_to(root).as_posix() for p in paths]
    if [n for n in names if n != "manifest.json"] != [r["member"] for r in manifest["files"]]:
        parser.error("Package member inventory differs")
    records = []
    for path, name in zip(paths, names):
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            parser.error("Invalid package member")
        data = path.read_bytes()
        records.append({"member": name, "bytes": len(data), "sha256": sha(data)})
    if [r for r in records if r["member"] != "manifest.json"] != manifest["files"]:
        parser.error("Package bytes differ from manifest")
    with zipfile.ZipFile(args.output, "x", compression=zipfile.ZIP_STORED) as archive:
        for path, record in zip(paths, records):
            info = zipfile.ZipInfo(record["member"], date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_STORED
            data = path.read_bytes()
            if sha(data) != record["sha256"]:
                raise ValueError("Package changed during archive creation")
            archive.writestr(info, data)
    result = {"schema": "dofa-zip-members-v1", "archive": {
        "bytes": args.output.stat().st_size, "sha256": sha(args.output.read_bytes())},
        "files": records, "zip_policy": "sorted members; stored; 1980-01-01; Unix regular 0644; no extras/comments"}
    with members_path.open("x") as out:
        json.dump(result, out, sort_keys=True, indent=2, allow_nan=False)
        out.write("\n")
    print(json.dumps(result["archive"], sort_keys=True))


if __name__ == "__main__":
    main()
