# DOFA saved numerical companion

This package reconstructs the saved arithmetic for a completed comparison of
numeric DOFA inputs **13.78** and **3.75** on five geographic test regions.
The comparison tests the effect of the numeric band input. The value 3.75
follows the upstream Sentinel-1 convention; the appropriate Cassini value
remains uncertain. Both numbers condition the learned embedding; neither
denotes a physical Cassini wavelength, and no physical-unit conversion is
performed.

| Display region | Stored fold | Cells (13.78, 3.75) | Training rows per input | Test rows per input |
|---|---|---|---|---|
| Region 1 | 0 | 0, 1 | 14603 | 3660 |
| Region 2 | 1 | 2, 3 | 12542 | 4497 |
| Region 3 | 2 | 4, 5 | 12348 | 5721 |
| Region 4 | 3 | 6, 7 | 13350 | 4748 |
| Region 5 | 4 | 8, 9 | 14644 | 4620 |

`cells/cell-00.json` through `cell-09.json` contain exact ordered test IDs,
integer true/predicted labels, probabilities, class indices and band values
projected from the ten completed fit records. Class/probability-column order
is **plains, dunes, hummocky, labyrinths, lakes, craters** (indices 0–5).
JSON strings, integers and floating-point values are preserved without rounding
or casting back to float32. The checker uses binary64 arithmetic. There are
23,246 test cases per input, 46,492 saved rows across all ten cells.

`expected.json` freezes each independent report's confusion counts, support,
prediction counts, true positives, per-class and macro precision/recall/F1,
kappa, producer diagnostics and descriptive readout. Its fold statistics were
separately derived with standard-library mean/sample SD from those fixed metrics.
The checker pins this file's SHA-256; it never rewrites expectations. Ordered
ID/label digests and the full member manifest protect membership and exact data.
Changing the package and all its checkers is outside this integrity claim.

Confusion rows are true classes and columns are predictions. For each class,
P = TP/predicted, R = TP/support, and F1 = 2TP/(support + predicted).
A zero denominator yields zero; all six classes remain in every macro mean.
Kappa is (observed agreement − chance agreement)/(1 − chance agreement), with
chance from the two confusion marginals; undefined kappa is rejected.
Equal-region means and sample SDs use all five regions (`ddof=1`), including
per-class metrics, macro metrics, kappa and counts. Paired differences are
**3.75 minus 13.78** in the same region, summarized over all five pairs.
Rates/kappa are fractions and counts are counts; the explicitly named macro-F1
percentage-point fields multiply differences by 100. Pooled confusion metrics
are secondary and are not the equal-region averages. Counts compare exactly;
metric/statistic comparisons allow absolute 1e-12, relative zero. Probability
sums allow 1e-6; saved probabilities must be finite in [0,1] and saved predictions
must attain the row maximum. Probabilities are validated, not regenerated.

With Python 3 and NumPy already installed, run from the extracted package:

```sh
sh reproduce.sh ../dofa-reproduction
```

The output directory must be new and outside the package. This writes the new
`report.json`, `controls.log`, reproducible ZIP and complete ZIP-member manifest.
Individual commands are `python3 -B replay.py --output ../report.json`,
`python3 -B test_controls.py`, and
`python3 -B build_zip.py --output ../dofa-numerical-companion.zip`.
No installation, download or network connection is needed. ZIP members are
sorted, uncompressed, dated 1980-01-01 and mode 0644 to avoid compressor and
filesystem timestamp variability. Invoke the shell script with `sh`.

The original C1 readout uses a fresh training-only StandardScaler and balanced
LBFGS logistic regression (C=1, seed 0, tolerance 1e-4, max_iter=2000), one fit
per input/region on 768 float32 features, one numerical thread, with no tuning.
`recipe.json` preserves all resolved producer parameters, original C1 source
file SHA-256 identifiers, upstream public Git identity and checkpoint SHA-256.
Those parameters describe the completed producer, not instructions for a new fit.
The pinned upstream source is [DOFA version 1](https://github.com/zhu-xlab/DOFA/tree/73ff5c0721da322689ae890bed5b4efd78935f47).
The completed comparison held the encoder weights, image membership and
preprocessing recipe fixed across inputs; the two inputs have their own feature
matrices and fresh classifiers. This export leaves all weights, features and
scientific originals untouched and includes none of those payloads.

This is saved arithmetic only: no image inference, feature extraction, estimator
loading, probability generation or fitting is replayed. It does not demonstrate
full GPU reproducibility. The tests cover corrupt expected counts, reordered
rows/cells, missing/duplicate cells and invalid probability/label data, bypassing
file checks where needed to test semantic rejection. They do not repeat native
estimator gates. The five-region comparison is descriptive and exploratory:
tests were previously inspected, training folds overlap, labels derive from a
map, and rare-class supports are small (Region 2 has one Craters case; Region 3
has nine Lakes cases). No independent geological, causal pretraining or
statistical significance claim follows from these paired differences.

See `NOTICE.md`, `LICENSE`, `DATA_LICENSES.md` and `THIRD_PARTY_NOTICES.md` for
the existing anonymous review license and retained source credits.
