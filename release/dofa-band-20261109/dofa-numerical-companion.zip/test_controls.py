"""Small corruption controls for this saved-arithmetic export; no native model gates."""
import copy
from pathlib import Path
import unittest

import replay


class ExportControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root = Path(__file__).resolve().parent
        cls.expected = replay.load(root / "expected.json")
        cls.cells = [replay.load(root / f"cells/cell-{i:02d}.json") for i in range(10)]

    def test_corrupt_count_uses_reconstructed_confusion(self):
        expected = copy.deepcopy(self.expected)
        expected["cells"][0]["metrics"]["confusion_counts"][0][0] += 1
        # Deliberately bypass file hashes: this checks arithmetic, not only checksum rejection.
        with self.assertRaisesRegex(ValueError, "confusion_counts.*differs"):
            replay.validate_cells(self.cells, expected)

    def test_reordered_rows_in_both_arms(self):
        cells = copy.deepcopy(self.cells)
        for cell in cells[:2]:
            for field in ("tile_ids", "true_labels", "predictions", "probabilities"):
                cell[field][0], cell[field][1] = cell[field][1], cell[field][0]
        with self.assertRaisesRegex(ValueError, "Ordered IDs differ"):
            replay.validate_cells(cells, self.expected)

    def test_missing_cell(self):
        with self.assertRaisesRegex(ValueError, "All ten cells required"):
            replay.validate_cells(self.cells[:-1], self.expected)

    def test_duplicate_and_reordered_cells(self):
        for indices in ([0, 0, *range(2, 10)], [1, 0, *range(2, 10)]):
            with self.subTest(indices=indices):
                with self.assertRaisesRegex(ValueError, "Cell order or identity differs"):
                    replay.validate_cells([self.cells[i] for i in indices], self.expected)

    def test_invalid_probability_and_label(self):
        for value in (float("nan"), -0.1, 1.1):
            cells = copy.deepcopy(self.cells)
            cells[0]["probabilities"][0][0] = value
            with self.subTest(value=str(value)):
                with self.assertRaisesRegex(ValueError, "Invalid probabilities"):
                    replay.validate_cells(cells, self.expected)
        cells = copy.deepcopy(self.cells)
        cells[0]["true_labels"][0] = True
        with self.assertRaisesRegex(ValueError, "Invalid true_labels"):
            replay.validate_cells(cells, self.expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)
