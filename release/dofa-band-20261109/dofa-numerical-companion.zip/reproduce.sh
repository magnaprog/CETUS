#!/bin/sh
set -eu
if [ "$#" -ne 1 ]; then
    echo "Usage: sh reproduce.sh NEW_EXTERNAL_OUTPUT_DIRECTORY" >&2
    exit 2
fi
companion_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -- "$1"
companion_output=$(CDPATH= cd -- "$1" && pwd)
python3 -B "$companion_root/replay.py" --output "$companion_output/report.json"
python3 -B "$companion_root/test_controls.py" > "$companion_output/controls.log" 2>&1
python3 -B "$companion_root/build_zip.py" --output "$companion_output/dofa-numerical-companion.zip"
