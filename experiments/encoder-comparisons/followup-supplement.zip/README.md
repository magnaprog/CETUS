# SAR coverage and map labels

Use Python 3.12.3 and NumPy 2.4.4. Each subdirectory has its own replay command.

- `coverage/` compares class counts, confusion matrices and scores for all,
  complete and partial SAR coverage across 115 saved prediction vectors. It
  reads `scientific-supplement.zip` from the same release. There are 2,643
  partial-coverage tiles in the five test sets.
- `label-support/` reconstructs the map vote for all 2,651 partial-coverage
  catalog tiles and an inspection sample of 34 complete tiles. It contains
  2,685 sampled map grids with SAR weights and 60 inspection packets with
  masks. The vote inputs reproduce the saved counts. They do not establish
  independent geological labels or verify image registration.

Write each report outside the extracted archive. SHA256SUMS covers all other
members. See DATA_CREDITS.md for the image and map sources and LICENSE for
the terms of the author-owned code.
