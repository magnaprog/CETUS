Kevin Lee wrote the CETUS coverage and map-vote code. Preserve LICENSE and
DATA_CREDITS.md with redistributed copies. The original notices and scientific
source attributions remain in the distribution. The two calculations use the
saved terrain labels, predictions and inspection arrays.
