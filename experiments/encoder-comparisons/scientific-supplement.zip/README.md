# Reconstruct the Titan terrain results

The five geographic splits use 23,380 catalog tiles, of which 23,246 appear in a
test set. The saved records cover logistic regression on all eight feature sets,
frozen heads trained by SGD, nearest-neighbor classification, partial encoder
training and 80 fits varying feature scaling and regularization.

Run from the extracted archive using Python 3.12.3 and NumPy 2.4.4. Use a new
path for the JSON report.

```sh
python3 -B scripts/replay_metrics.py --output ../saved-metric-replay.json
python3 -B scripts/prepare_tables.py --output paper/tables --check
```

The first command checks file hashes, split membership, 315 prediction vectors,
sixteen fitting settings and twenty scaling and penalty contrasts. The second
checks all eleven TeX tables using the Python standard library.

Predictions are scored against the terrain map. The calculation gives each of
the six classes equal weight, using zero for undefined ratios. It averages
seed metrics within each region and reports the mean and sample SD across the
five regions. Nearest neighbors have one prediction vector per model and
region. Counts, tile IDs and labels must agree exactly. The absolute tolerance
for derived metrics and SDs is 1e-12. The 80-fit archive also contains training
probabilities and coefficients. The replay uses test predictions and does
not refit classifiers or recalculate gradients. Twenty-three fits reached the
iteration limit and 54 exceeded the recorded gradient threshold.

The class order is Plains, Dunes, Hummocky, Labyrinths, Lakes and Craters
(indices 0–5). The splits pin `data/catalog.json` and predictions follow
catalog order within each test fold. Map votes count known map cells, including
cells where SAR pixels are missing. A separate raster reconstruction differed
at seven cells. The predictions here use the released catalog labels. Foldwise
image normalization is recorded in `results/frozen_results.json`. The ancillary
VIMS fields store display samples. The classifier uses SAR.

## Data and software

The [Titan image archive](https://github.com/magnaprog/CETUS/releases/download/v0.2.0/titan-images.tar.zst)
contains the 23,380 processed tiles. The [data access guide](https://github.com/magnaprog/CETUS/blob/v0.2.0/experiments/encoder-comparisons/DATA_ACCESS.md)
gives the checksum and extraction instructions. To run the models on the
images, use the corresponding execution software and encoder weights.

- USGS Astrogeology, Cassini SAR HiSAR Global Mosaic 351 m:
  https://astrogeology.usgs.gov/search/map/titan_cassini_sar_hisar_global_mosaic_351m
  Attribute the Cassini SAR Team, JPL and USGS Astrogeology. This source record
  identifies the mosaic; it is not an anonymous processed-tile archive.
- Titan Global Map Shapefiles, version 1, Ashley Schoenfeld, corresponding to
  Lopes et al. (2020): https://data.mendeley.com/datasets/f6jrtyfp66/1
  DOI 10.17632/f6jrtyfp66.1; CC BY 4.0.
- VIMS/ISS mosaic record for retained ancillary catalog fields:
  https://data.caltech.edu/records/8q9an-yt176 ; DOI 10.22002/D1.1173.
  Preserve the BSD notice in THIRD_PARTY_NOTICES.md.


Kevin Lee wrote the author-owned code. Keep LICENSE, DATA_LICENSES.md,
THIRD_PARTY_NOTICES.md and the CROMA license with redistributed copies.
