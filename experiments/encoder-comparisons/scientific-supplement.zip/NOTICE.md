Kevin Lee is the author of the CETUS material. The original MIT license and
third-party notices, including the CROMA license, accompany this archive.

Catalog and five fold manifests preserve the existing sanitized release bytes.
The native execution catalog has a different hash because its private paths and
legacy split fields were omitted in that prior export. Original execution
identities must not be relabeled as a fresh public-input run.

This copy removes five absolute split-source paths from the common summary,
private acceptance/source bindings from the scaling aggregate, and nonessential
execution/source/environment routing from the 80 individual fit records.
Saved numerical arrays are byte-identical, including probabilities, labels,
predictions and IDs. Retained JSON numerical values and types are unchanged.
The partial-training JSON selects the 75 existing adaptation test records;
validation and training-substitution records are omitted. No scientific values
or labels were corrected. Other shared prediction files retain some controls
that the minimal consumer does not evaluate.


The replay script calculates six-class metrics from saved records. The original
ZIP and its packaging records are available at public CETUS commit
6abf690c404e72d7233aaf06dfefd74ed225d36a. The public edition renames the table
generator and the table directory and updates the documentation and inventory.
